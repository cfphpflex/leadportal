import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import {teamMember} from '../form/schema'
import styled from 'styled-components'
import { Button, Title, BigTitle} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { patch,get } from '../../provider/api' //UPDATE only needs PATCH and GET
import { useRom } from '../../provider/rom'
import EE from '../utils/events'

const EditTeamMember = () => {
    const rom = useRom()
    const {ui} = rom
    const {roles,user} = ui

    const ST = {
        first_name: "DANNY",
        id: 14,
        last_name: "DAN",
        npi: 1588808943
    }

    const [selectedTM, setSelectedTM] = useState(ST)

    const [submitting, setSubmitting] = useState(null)
    const [renderForm, setRenderForm] = useState(true)
    const [initialValues, setInitialValues] = useState({})

    const history = useHistory()

    //componentdidmount
    useEffect(()=>{
        EE.on('fill-form',(e)=>{
            let updates = {...e}
            console.log('updates',updates)
            setInitialValues(updates)
            refreshForm()
        })
    },[])

    function refreshForm(){
        setRenderForm(false)
        setTimeout(()=>{
            setRenderForm(true)
        },20)
    }

    async function editTeamMember(f){
        const oP = f.office_phone
        let pFormatted = ''+oP['0']+oP['1']+oP['2']

        const mP = f.mobile_phone
        let MPFormatted = ''+mP['0']+mP['1']+mP['2']

        console.log('f',f)

        const data = {
            "user":
                {
                    "user_role_id": f.role&&f.role.id,
                    "username": f.email,
                    "password": f.password
                },
            "practice_id": user&&user.id,
            "npi": f.npi+'',
            "first_name": f.first_name,
            "last_name": f.last_name,
            "phone_number":
                [
                    {
                        "phone_name": "Office Phone",
                        "phone_number": pFormatted?pFormatted:''
                    },
                    {
                        "phone_name": "Mobile Phone",
                        "phone_number": MPFormatted?MPFormatted:''
                    }
                ]
        }

        try{
            setSubmitting(true)
            const tm = await patch('practice_team_member'+user.id,data)
            history.push('/teamManagement')
        } catch(e){
            console.log('e',e)
        }

        setSubmitting(false)
    }



    const aButtons = [
        {type:'submit','text':'Save Changes',color:'submit'},
    ]

    const tmConfig = teamMember.map(tm=>{
        return {
            ...tm,
            options:tm.options&&tm.options.map(o=>{
                return {...o}
            })
        }
    })

    if (roles&&roles.length) {
        tmConfig[1].options = [...roles]
    }

    return (<Wrap>
        <Title title={'Edit Team Member'}/>
        {renderForm&&<Form
            config={tmConfig}
            submitting={submitting}
            buttons={aButtons}
            disabled={selectedTM?true:false}
            initialValues={initialValues}
            inputWidth={386}
            formStyle={{flexWrap:'wrap',flexDirection:'row',justifyContent:'space-between',width:1238}}
            onSubmit={(v)=>editTeamMember(v)}
        />}
        }

    </Wrap>);
}

export default EditTeamMember

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    align-content:center; 
`
