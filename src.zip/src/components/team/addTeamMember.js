import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import {teamMember} from '../form/schema'
import styled from 'styled-components'
import { Button, Title, BigTitle, Shadow, openNotification} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { post,del, get } from '../../provider/api'
import { useRom } from '../../provider/rom'
import EE from '../utils/events'
import { asyncForEach } from '../utils/helpers'

const AddTeamMember = () => {
    const rom = useRom()
    const {ui} = rom

    const ST = {
        first_name: "DANNY",
        id: 14,
        last_name: "DAN",
        npi: 1588808943
    }
    
    const [step, setStep] = useState(0)
    const [selectedTM, setSelectedTM] = useState(ST)
    const [userNots, setUserNots] = useState({})
    const [userPerms, setUserPerms] = useState({})

    const [submitting, setSubmitting] = useState(null)
    const [renderForm, setRenderForm] = useState(true)
    const [initialValues, setInitialValues] = useState({})
    const {notifications,permissions,roles,user} = ui

    const history = useHistory()

    

    //componentdidmount
    useEffect(()=>{

        (async()=>{

            return

            const uN = await get(`practice_team_member_notification/all/${1}`)
            if (uN) {
                let userNotsInits = {}
                uN.forEach((n)=>{
                    userNotsInits[n.name] = true
                })
                setUserNots(userNotsInits)
                refreshForm()
            }

            const uP = await get(`practice_team_member_permission/all/${1}`)
            if (uP) {
                let userPermsInits = {}
                uP.forEach((p)=>{
                    userPermsInits[p.name] = true
                })
                setUserPerms(userPermsInits)
                refreshForm()
            }
            
        })()


        EE.on('fill-form',(e)=>{
            let updates = {...e}
            console.log('updates',updates)
            setInitialValues(updates)
            refreshForm()
        })
    },[])

    function refreshForm(){
        setRenderForm(false)
        setTimeout(()=>{
            setRenderForm(true)
        },20)
    }

    async function createTeamMember(f){
        console.log('f',f)
        const oP = f.office_phone
        let pFormatted = ''+oP['0']+oP['1']+oP['2']

        const mP = f.mobile_phone
        let MPFormatted = ''+mP['0']+mP['1']+mP['2']

    // HARD CODED WORKS

        const data = {
            "user":
                {
                    "user_role_id": f.role&&f.role.id,
                    "username": f.email,
                    "password": f.password
                },
            "practice_id": user&&user.id,
            "npi": f.npi+'',
            "first_name": f.first_name,
            "last_name": f.last_name,


        }

        /*
        "phone_name": "Office Phone",
            "phone_number": pFormatted?pFormatted:''
        */


            /*[
            {
                "phone_name": "Office Phone",
                "phone_number": pFormatted?pFormatted:''
            }

            ,
            {
                "phone_name": "Mobile Phone",
                "phone_number": MPFormatted?MPFormatted:''
            }
            ]*/


        try{
            setSubmitting(true)
            const tm = await post('practice_team_member',data)
            setSelectedTM(tm)
            setStep(1)
            setSubmitting(false)
            // history.push('/search')
        } catch(e){
            console.log('catch error res',e.response)
            const {data} = e.response.data
            const {validation_errors} = data&&data
            const {user} = validation_errors&&validation_errors
            if (user){
                const {username} = user&&user
                if (username&&username[0]){
                    openNotification(null,username[0])
                }
            }
            setSubmitting(false)
        }
        
        setSubmitting(false)
    }

    async function saveNotifications(v){
        setSubmitting(true)
        const toProcess = {}
        notifications&&notifications.map((p,i)=>{
            toProcess[p.name] = v.name
        })

        // workaround for no batch notifications call
        const objKeys = Object.keys(toProcess)
        await asyncForEach(objKeys,async(p,i)=>{
            const name = p
            const value = toProcess[p]
            //await addNotification(name)


            if (name) await addNotification(name)
            else await removeNotification(name)
    })

        setSubmitting(false)
}

    async function savePermissions(v){
        setSubmitting(true)
        const toProcess = {}
        permissions&&permissions.map((p,i)=>{
            toProcess[p.name] = v.name
        })

        // workaround for no batch permission call
        const objKeys = Object.keys(toProcess)
        await asyncForEach(objKeys,async(p,i)=>{
            const name = p
            const value = toProcess[p]
            console.log("test value");
            console.log(name);
             //await addPermission(name)


            if (name) await addPermission(name)
            else await removePermission(name)

        })

        setStep(2)
        setSubmitting(false)

    }

    async function addPermission(name){
        const perm = permissions.find(f=>f.name===name)
        if (!perm) return

        const data = {
   //The values must be eunique
           // "practice_team_member_id": 3,
            //"permission_id": 3

            "practice_team_member_id": selectedTM&&selectedTM.id,
            "permission_id": perm.id
        }
        console.log(data);
        await post('practice_team_member_permission',data)

    }

    async function addNotification(name){
        const noti = notifications.find(f=>f.name===name)
        if (!noti) return

        const data = {

            //"practice_team_member_id": 2,
            //"notification_id": 2

            "practice_team_member_id": selectedTM&&selectedTM.id,
            "notification_id": noti.id
        }
        await post('practice_team_member_notification',data)  
    }

    async function removePermission(name){
        const perm = permissions.find(f=>f.name===name)
        if (!perm) return
        await del(`practice_team_member_permission/${perm.id}`)
    }

    async function removeNotification(name){
        const noti = notifications.find(f=>f.name===name)
        if (!noti) return
        await del(`practice_team_member_notification/${noti.id}`) 
    }

    const aButtons = [
        {type:'submit','text':'Next',color:'secondary'},
    ]
    const bButtons = [
        // {type:'cancel','text':'Back',color:'submit', },
        {type:'submit','text':'Next',color:'secondary'},
    ]
    const cButtons = [
        {type:'cancel','text':'Back',color:'submit'},
        {type:'submit','text':'Finish',color:'secondary'},
    ]

    const tabButtons = [
        {
            type:'util',
            color:'sea',
            text:'Team Member',
            func:()=>setStep(0),
            style:{width:168}
        },
        {
            type:'util',
            color:'sea',
            text:'Permissions',
            func:()=>setStep(1),
            dead:!selectedTM,
            style:{width:168}
        },
        {
            type:'util',
            color:'sea',
            text:'Notifications',
            func:()=>setStep(2),
            dead:!selectedTM,
            style:{width:168}
        },
    ]

    const permissionConfig = []
    const notificationConfig = []

    permissions&&permissions.forEach((p)=>{
        permissionConfig.push({
            label:p.name,
            name:p.name,
            id:p.id,
            type:'boolean',
        })
    })

    notifications&&notifications.forEach((n)=>{
        notificationConfig.push({
            label:n.name,
            name:n.name,
            id:n.id,
            type:'boolean',
        })
    })

    const tmConfig = teamMember.map(tm=>{
        return {
            ...tm,
            options:tm.options&&tm.options.map(o=>{
                return {...o}
            })
        }
    })

    if (roles&&roles.length) {
        tmConfig[1].options = [...roles]
    }

    return (<Wrap>
            <Title title={'Add Team Member'}/>

            <ButtonRow>
                <Shadow>
                    {tabButtons.map((b,i)=>{
                        return <Button
                        type={b.type}
                        text={b.text} key={i}
                        invert={step!==i}
                        dead={b.dead}
                        color={b.color}
                        style={{margin:0,...b.style}}
                        onClick={()=>b.func()}
                        />
                    })}
                </Shadow>
            </ButtonRow>

            {step === 0 ?
            <>
            {renderForm&&<Form
                config={tmConfig}
                submitting={submitting}
                buttons={aButtons}
                disabled={selectedTM?true:false}
                initialValues={initialValues}
                inputWidth={386}
                formStyle={{flexWrap:'wrap',flexDirection:'row',justifyContent:'space-between',width:1238}}
                onSubmit={(v)=>createTeamMember(v)}
            />}
            </>
            :step === 1 ?
            <>
            {renderForm&&<Form
                config={permissionConfig}
                submitting={submitting}
                buttons={bButtons}
                initialValues={userPerms}
                inputWidth={760}
                // onSwitchChange={(e)=>{
                //     console.log('e',e)
                //     const {name, value} = e.target
                //     if (value) addPermission(name)
                //     else removePermission(name)
                // }}
                onCancel={()=>setStep(0)}
                onSubmit={(v)=>savePermissions(v)}
            />}
            </>
            :
            <>
            {renderForm&&<Form
                config={notificationConfig}
                initialValues={userNots}
                submitting={submitting}
                buttons={cButtons}
                // onSwitchChange={(e)=>{
                //     console.log('e',e)
                //     const {name, value} = e.target
                //     if (value) addNotification(name)
                //     else removeNotification(name)
                //     }}
                inputWidth={760}
                supplementButton={(
                    <Button
                    type={'submit'}
                    text={'Add Another Team Member'} 
                    color={'third'}
                    style={{margin:40, minWidth:480}}
                    onClick={()=>{
                        setSelectedTM(null)
                        setStep(0)
                        }}/>
                    )
                }
                onCancel={()=>setStep(1)}
                onSubmit={(v)=>saveNotifications(v)}
            />}
            </>
            }

    </Wrap>);
}

export default AddTeamMember

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    align-content:center; 
`

const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:30px;
`
