import React, { useState, useEffect, useCallback, useContext } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle, openNotification} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { post } from '../../provider/api'
import { useRom } from '../../provider/rom'
import EE from '../utils/events'
import ItemList from '../lists/itemList'
import { teamMembersHeaders } from '../listHeaders'
import { fakeTeamMembers } from '../fakeData'

const TeamManagement = () => {
    const rom = useRom()
    const [submitting, setSubmitting] = useState(null)
    const history = useHistory()
    const {ui, setUI} = rom

    const buttons = [
        {
            color:'submit',
            text:'Edit',
            func:(p)=>edit(p),
            style:{width:164}
        },
        {
            color:'cancel',
            text:'Archive',
            func:(p)=>archive(p),
            style:{width:164}
        },
    ]

    function edit(p){
        // put p.id in path
        history.push('/editTeamMember')
    }

    function archive(p){
        openNotification('', 'This action cannot be undone',(<div style={{display:'flex'}}>
            <Button style={{width:150}} color={'cancel'} text={'Archive'}/>
            <Button style={{width:150}} color={'save'} text={'Cancel'}/>
            </div>),null,'topRight',{width: 650,
        marginLeft: 335 - 650,
        height: 161,})
    }


    return (<Wrap>
            <Title title={'Team Management'}/>

            <Button 
                color={'third'}
                text={'Add New Team member'}
                onClick={()=>history.push('/addTeamMember')}
                style={{position:'absolute',
                top:30,
                width:280,
                right:38}}
            />

            <div style={{display:'flex',padding:50,paddingTop:20,width:'100%'}}>
            
                    <ItemList 
                    items={fakeTeamMembers}
                    headers={teamMembersHeaders}
                    buttons={buttons} />
                </div>
    </Wrap>);
}

export default TeamManagement

const Wrap = styled.div`
    display:flex;
    flex:1;
    width:100%;
    position:relative;
    flex-direction:column;
    align-content:center; 
`

