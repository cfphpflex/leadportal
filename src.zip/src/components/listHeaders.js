
export const patientDevicesHeaders = [
    {label:'Patient',key:'name'},
    {label:'Patient ID',key:'id'},
    {label:'PortableConnect Serial Number',key:'pcSerial'},
    {label:'AccuAngle Serial Number',key:'aaSerial'},
    {label:'AccuStep Serial Number',key:'asSerial'},
    {label:'Location',key:'location'},
    {label:'Days Remaining',key:'daysRemaining'},
]

export const patientsHeaders = [
    {label:'Patient',key:'name'},
    {label:'Physical Therapist',key:'pt'},
    {label:'Surgeon',key:'surgeon'},
    {label:'Procedure',key:'procedure'},
    {label:'Post-Op Day',key:'postOpDay'},
    {label:'Pain',key:'pain'},
    {label:'Rom Ext/F',key:'romExtF'},
    {label:'Session Comp/Tot',key:'sessionCompTot'},
    {label:'Last Session',key:'lastSession'},
    {label:'Alerts',key:'alerts'},
]

export const practicesHeaders = [
    {label:'Practice name',key:'name'},
    {label:'Practice type',key:'type'},
    {label:'Location',key:'location'},
    {label:'Phone',key:'phone'}
]

export const teamMembersHeaders = [
    {label:'Team Member',key:'name'},
    {label:'E-mail Address',key:'email'},
    {label:'Phone',key:'phone'},
    {label:'Role',key:'role'}
]

export const treatmentTemplatesHeaders = [
    {label:'Template Name',key:'name'},
    {label:'Number of Days',key:'days'},
    {label:'Description',key:'description'}
]

export const devicesHeaders = [
    {label:'Device',key:'device'},
    {label:'Serial Number',key:'serialNumber'},
    {key:'space'},
    {key:'space'},
    {key:'space'},
    {key:'space'},
    {key:'space'},
    {label:'Status',key:'status'},
    
]

