import EventEmitter from 'eventemitter3'

var EE = new EventEmitter()

export default EE