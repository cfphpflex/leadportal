import React, { Component } from "react";
import { useTable, useSortBy } from "react-table";

import "./styles/patientsTable.css";

import Up from "./../../images/tableUp.png";
import Down from "./../../images/tableDown.png";

function Table({ columns, data }) {
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
    },
    useSortBy
  );

  const firstPageRows = rows.slice(0, 20);

  return (
    <>
      <table className="table" {...getTableProps()}>
        <thead className="tableHead">
          {headerGroups.map((headerGroup) => (
            <tr {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map((column) => (
                <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                  {column.render("Header")}
                  <span>
                    {column.isSorted
                      ? column.isSortedDesc
                        ? " 🔽"
                        : " 🔼"
                      : ""}
                  </span>
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody {...getTableBodyProps()}>
          {firstPageRows.map((row, i) => {
            prepareRow(row);
            return (
              <tr className="tableRow" {...row.getRowProps()}>
                {row.cells.map((cell) => {
                  return (
                    <td className="tableRowContents" {...cell.getCellProps()}>
                      {cell.render("Cell")}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
      {/* <div>Showing the first 20 results of {rows.length} rows</div> */}
    </>
  );
}

function PatientsTable() {
  const columns = React.useMemo(() => [
    {
      Header: "Patient",
      accessor: "patient",
    },
    {
      Header: "Physical Therapist",
      accessor: "therapist",
    },
    {
      Header: "Surgeon",
      accessor: "surgeon",
    },
    {
      Header: "Procedure",
      accessor: "procedure",
    },
    {
      Header: "Post-op Day",
      accessor: "postop",
    },
    {
      Header: "Pain",
      accessor: "pain",
    },
    {
      Header: "ROM EXT/F",
      accessor: "extf",
    },
    {
      Header: "Sesson COMP/TOT",
      accessor: "comptot",
    },
    {
      Header: "Last Session",
      accessor: "lastSession",
    },
  ]);

  const data = [
    {
      patient: "frid",
      therapist: "doe",
      surgeon: "fred again",
      postop: "3",
      pain: "3",
      extf: "1/1",
      comptot: "10/3",
      lastSession: "date",
    },
    {
      patient: "fred",
      therapist: "doe",
      surgeon: "fred again",
      postop: "3",
      pain: "3",
      extf: "1/1",
      comptot: "10/3",
      lastSession: "date",
    },
    {
      patient: "frad",
      therapist: "doe",
      surgeon: "fred again",
      postop: "3",
      pain: "3",
      extf: "1/1",
      comptot: "10/3",
      lastSession: "date",
    },
  ];

  return <Table columns={columns} data={data} />;
}

export default PatientsTable;
