import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import {teamMember} from '../form/schema'
import styled from 'styled-components'
import { Button, Title, BigTitle, Select, SubHeader, Shadow} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { post, del, get } from '../../provider/api'
import { useRom } from '../../provider/rom'
import EE from '../utils/events'
import { asyncForEach } from '../utils/helpers'

const Settings = () => {

    const dropdownoptions = [
        {label:'Nikki',name:'nikki',id:'0'},
        {label:'Michea',name:'micheal',id:'1'}
    ]

    const rom = useRom()
    const {ui} = rom

    const [step, setStep] = useState(0)
    const [selectedTM, setSelectedTM] = useState(dropdownoptions[0])
    const [userNots, setUserNots] = useState({})
    const [userPerms, setUserPerms] = useState({})

    const [submitting, setSubmitting] = useState(null)
    const [renderForm, setRenderForm] = useState(true)
    const [initialValues, setInitialValues] = useState({})
    const {notifications,permissions,roles,user} = ui

    const history = useHistory()

    //componentdidmount
    useEffect(()=>{

        (async()=>{

            return

            const uN = await get(`practice_team_member_notification/all/${1}`)
            if (uN) {
                let userNotsInits = {}
                uN.forEach((n)=>{
                    userNotsInits[n.name] = true
                })
                setUserNots(userNotsInits)
                refreshForm()
            }

            const uP = await get(`practice_team_member_permission/all/${1}`)
            if (uP) {
                let userPermsInits = {}
                uP.forEach((p)=>{
                    userPermsInits[p.name] = true
                })
                setUserPerms(userPermsInits)
                refreshForm()
            }
            
        })()


        EE.on('fill-form',(e)=>{
            let updates = {...e}
            console.log('updates',updates)
            setInitialValues(updates)
            refreshForm()
        })
    },[])

    function refreshForm(){
        setRenderForm(false)
        setTimeout(()=>{
            setRenderForm(true)
        },20)
    }

    async function saveNotifications(v){
        setSubmitting(true)
        const toProcess = {}
        notifications&&notifications.map((p,i)=>{
            toProcess[p.name] = v.name
        })

        // workaround for no batch notifications call
        const objKeys = Object.keys(toProcess)
        await asyncForEach(objKeys,async(p,i)=>{
            const name = p
            const value = toProcess[p]
            if (value) await addNotification(name)
            else await removeNotification(name)
    })

        setSubmitting(false)
}

    async function savePermissions(v){
        setSubmitting(true)
        const toProcess = {}
        permissions&&permissions.map((p,i)=>{
            toProcess[p.name] = v.name
        })

        // workaround for no batch permission call
        const objKeys = Object.keys(toProcess)
        await asyncForEach(objKeys,async(p,i)=>{
            const name = p
            const value = toProcess[p]
            if (value) await addPermission(name)
            else await removePermission(name)
        })

        setStep(2)
        setSubmitting(false)

    }

    async function addPermission(name){
        const perm = permissions.find(f=>f.name===name)
        if (!perm) return

        const data = {
            "practice_team_member_id": selectedTM&&selectedTM.id,
            "permission_id": perm.id,
        }
        await post('practice_team_member_permission',data)   
    }

    async function addNotification(name){
        const noti = notifications.find(f=>f.name===name)
        if (!noti) return

        const data = {
            "practice_team_member_id": selectedTM&&selectedTM.id,
            "notification_id": noti.id,
        }
        await post('practice_team_member_notification',data)  
    }

    async function removePermission(name){
        const perm = permissions.find(f=>f.name===name)
        if (!perm) return
        await del(`practice_team_member_permission/${perm.id}`)
    }

    async function removeNotification(name){
        const noti = notifications.find(f=>f.name===name)
        if (!noti) return
        await del(`practice_team_member_notification/${noti.id}`) 
    }

    const isNotifications = window.location.pathname === '/notifications'

   

    const tabButtons = [
        {
            type:'util',
            color:'sea',
            text:'Permissions',
            invert:isNotifications,
            func:()=>history.push('/permissions'),
        },
        {
            type:'util',
            color:'sea',
            text:'Notifications',
            invert:!isNotifications,
            func:()=>history.push('/notifications'),
        },
    ]

    const bButtons = [
        {type:'cancel','text':'Cancel',color:'cancel', },
        {type:'submit','text':'Save',color:'secondary'},
    ]
    const cButtons = [
        {type:'cancel','text':'Cancel',color:'cancel'},
        {type:'submit','text':'Save',color:'secondary'},
    ]

    const permissionConfig = []
    const notificationConfig = []

    permissions&&permissions.forEach((p)=>{
        permissionConfig.push({
            label:p.name,
            name:p.name,
            id:p.id,
            type:'boolean',
        })
    })

    notifications&&notifications.forEach((n)=>{
        notificationConfig.push({
            label:n.name,
            name:n.name,
            id:n.id,
            type:'boolean',
        })
    })

    const tmConfig = teamMember.map(tm=>{
        return {
            ...tm,
            options:tm.options&&tm.options.map(o=>{
                return {...o}
            })
        }
    })

    if (roles&&roles.length) {
        tmConfig[1].options = [...roles]
    }

    

    return (<Wrap>
            <Title title={'Settings'}/>

            <div style={{display:'flex',width:'100%',
            justifyContent:'center'}}>
                <Select 
                    label='Team Member'
                    name='tm'
                    value={selectedTM}
                    onChange={(e)=>setSelectedTM(e)}
                    options={dropdownoptions}
                    style={{width:376}}
                />
            </div>

            <SubHeader title={selectedTM.name} style={{marginBottom:24,marginTop:2}}/>

            <ButtonRow>
                <Shadow>
                    {tabButtons.map((b,i)=>{
                        return <Button
                        type={b.type}
                        text={b.text} key={i}
                        invert={b.invert}
                        dead={b.dead}
                        color={b.color}
                        style={{margin:0,width:187}}
                        onClick={()=>b.func()}
                        />
                    })}
                </Shadow>
            </ButtonRow>

            { isNotifications?
            <>
            {renderForm&&<Form
                config={notificationConfig}
                initialValues={userNots}
                submitting={submitting}
                buttons={cButtons}
                // onSwitchChange={(e)=>{
                //     console.log('e',e)
                //     const {name, value} = e.target
                //     if (value) addNotification(name)
                //     else removeNotification(name)
                //     }}
                inputWidth={760}
                onCancel={()=>setStep(1)}
                onSubmit={(v)=>saveNotifications(v)}
            />}
            </> :
            <>
            {renderForm&&<Form
                config={permissionConfig}
                submitting={submitting}
                buttons={bButtons}
                initialValues={userPerms}
                inputWidth={760}
                // onSwitchChange={(e)=>{
                //     console.log('e',e)
                //     const {name, value} = e.target
                //     if (value) addPermission(name)
                //     else removePermission(name)
                // }}
                onCancel={()=>setStep(0)}
                onSubmit={(v)=>savePermissions(v)}
            />}
            </>
            }

    </Wrap>);
}

export default Settings

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    align-content:center; 
`

const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:30px;
`
