import React, { useState, useEffect, useCallback, useContext } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle, Detail } from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { patients } from '../fakeData'
import PatientPanel, {BigPanel, SmallPanel, PanelHead} from './shared/patientPanel'
import TopRow from './shared/topRow'
import ProtocolBox from './shared/protocolBox'
import {templates} from '../fakeTreatmentData'
import TheChart, {differentStyles} from './chartWrap'

const PatientProfile = (props) => {
  const patientID = parseInt(props.computedMatch.params.patientID)

  const [submitting, setSubmitting] = useState(null)
  const [expandedChartTitle, setExpandedChartTitle] = useState(null)
  const history = useHistory()

  const patient = patients.find(p=>p.id===patientID)
  if(!patient) {
    return <NotFound>Patient Not Found</NotFound>
  }

  async function create(v) {
    console.log('v', v)
    // setSubmitting(false)
  }

  const prData = [
    { name: 'procedure', label: 'Procedure' },
    { name: 'procedureDate', label: 'Procedure Date' },
    { name: 'lastSession', label: 'Last Session' },
    { name: 'postOpDay', label: 'Days Since Surgery' },
  ]

  const cData = [
    { name: 'extension', label: 'Extension' },
    { name: 'flexion', label: 'Flexion' },
    { name: 'pain', label: 'Pain Level' },
    { name: 'sessionCompTot', label: 'Sessions Comp/Tot' },
  ]

  const charts = [
    {title:'Extension',type:'line',yLabel:'DEGREES',unit:'°'},
    {title:'Flexion',type:'line',yLabel:'DEGREES',unit:'°'},
    {title:'Pain',type:'bar',yLabel:'PAIN LEVEL'},
    {title:'Ambulation',type:'line',yLabel:'STEPS TAKEN DAILY'},
    {title:'Strength',type:'line',yLabel:'LBS.'},
    {title:'Daily Pedaling Time',type:'line',yLabel:'MINUTES'},
    {title:'Total Revolutions',type:'line',yLabel:'REVOLUTIONS'},
    {title:'Completed Sessions',type:'line',yLabel:'COMPLETED SESSIONS'},
  ]

  // console.log("PATIENT DATA", patient)

  const template = templates[0]
  const protocols = template&&template.protocols
  const protocol = protocols&&protocols[0]

  return (<Wrap>

    <TopRow label="Patient Profile" backLabel="Patient List" 
      backAction={()=> history.push(`/patients`)}
    />

    <PatientPanel patient={patient} />

    <Row>
      <SmallPanel>
        <PanelHead>Procedure Information</PanelHead>
        <div style={{ display: 'flex', flex: 1, flexWrap: 'wrap', justifyContent: 'space-between' }}>
          {prData.map((d, i) => {
            return <Detail key={i} label={d.label} style={{ width: 230,marginTop:20 }} dataKey={d.name} name={patient[d.name]} />
          })}
        </div>
      </SmallPanel>

      <SmallPanel>
        <PanelHead>Current Progress</PanelHead>
        <div style={{ display: 'flex', flex: 1, flexWrap: 'wrap', justifyContent: 'space-between' }}>
          {cData.map((d, i) => {
            return <Detail key={i} label={d.label} style={{ width: 230,marginTop:20 }} dataKey={d.name} name={patient[d.name]} />
          })}
        </div>
      </SmallPanel>
    </Row>

    <ProtocolBox active protocol={protocol} index={0} protocols={protocols} />

    <WrapRow>
      {charts && charts.map((c,i)=>{
        const customColor = differentStyles[c.title] && differentStyles[c.title].backgroundColor
        const expanded = expandedChartTitle===c.title
        return <TheChart key={i} c={c} expanded={expanded}
          customColor={customColor} setExpandedChartTitle={setExpandedChartTitle}
          expandedChartTitle={expandedChartTitle}
        />
      })}
    </WrapRow>

  </Wrap>);
}

export default PatientProfile

const Wrap = styled.div`
  display:flex;
  flex:1;
  min-width:1300px;
  max-width:3000px;
  position:relative;
  flex-direction:column;
  ${'' /* justify-content:center; */}
  align-content:center; 
`
const WrapRow=styled.div`
  display:flex;
  justify-content:space-between;
  flex-wrap:wrap;
  width:1348px;
`
const Row=styled.div`
  display:flex;
  justify-content:space-between;
`
const NotFound = styled.div`
  flex:1;
  display:flex;
  align-items:center;
  justify-content:center;
`
