import React, {useRef,useEffect,useState,useCallback} from 'react'
import { useDrag, useDrop } from 'react-dnd'
import styled from 'styled-components'
import MaterialIcon from '@material/react-material-icon';
import update from 'immutability-helper'
import {emptyProtocol} from '../fakeTreatmentData'

/*
https://react-dnd.github.io/react-dnd/examples/sortable/simple
*/

export default function ReorderProtocols(props){
  const {editing, protocols, setProtocols} = props

  // function move(dragIndex, hoverIndex) {
  //   let newp = protocols ? [...protocols] : []
  //   let dragP = newp[dragIndex]; 
  //   newp.splice(dragIndex, 1);
  //   newp.splice(hoverIndex, 0, dragP); 
  //   setProtocols(newp)
  // }

  const moveProtocol = useCallback(
    (dragIndex, hoverIndex) => {
      const dragCard = protocols[dragIndex]
      setProtocols(
        update(protocols, {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragCard],
          ],
        }),
      )
    },
    [protocols],
  )

  function addProtocol(){
    const newProtocol={
      ...emptyProtocol,
      id:getRandomArbitrary(100,100000)
    }
    setProtocols([...protocols,newProtocol])
  }

  return <BlueBox>
    {protocols && protocols.map((p,i)=>{
      // if(!p) return <span key={i}></span>
      return <Protocol key={p.id} i={i} p={p} editing={editing} 
        move={moveProtocol}
      />
    })}
    {editing && <NewProtocol onClick={()=>addProtocol()}>+ Add Protocol</NewProtocol>}
  </BlueBox>
}

function Protocol(props){
  const {p,editing,i} = props
  const {id} = p

  const ref = useRef(null)
  const [, drop] = useDrop({
    accept: 'protocol',
    hover(item, monitor) {
      if (!ref.current) {
        return
      }
      const dragIndex = item.i
      const hoverIndex = i
      // Don't replace items with themselves
      if (dragIndex === hoverIndex) {
        return
      }
      // Determine rectangle on screen
      const hoverBoundingRect = ref.current.getBoundingClientRect()
      // Get vertical middle
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2
      // Determine mouse position
      const clientOffset = monitor.getClientOffset()
      // Get pixels to the top
      const hoverClientY = clientOffset.y - hoverBoundingRect.top
      // Dragging downwards
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return
      }
      // Dragging upwards
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return
      }
      if(props.move) props.move(dragIndex, hoverIndex)
      item.i = hoverIndex
    },
  })

  const [{ isDragging }, drag] = useDrag({
    item: { i, id, type:'protocol' },
    collect: monitor => ({
      isDragging: monitor.isDragging()
    }),
  })
  const opacity = isDragging ? 0.2 : 1
  drag(drop(ref))

  return <ProtocolWrap ref={ref} style={{opacity}}>
    <ProtocolLeft>
      {editing && <MaterialIcon icon={'drag_indicator'} 
        style={{cursor:'pointer',fontSize:24,color:'grey',marginRight:8}}
      />}
      {!editing && <div style={{marginRight:6,color:'#59acca'}}>{`Protocol ${i+1}:`}</div>}
      <div style={{marginRight:6,color:'#2f7489'}}>{`${p.label}${editing?':':''}`}</div>
      {editing && <div style={{color:'grey'}}>{p.purpose}</div>}
    </ProtocolLeft>
    {editing ? <MaterialIcon icon={'close'} 
      onClick={()=>{
        if(props.remove) props.remove()
      }}
      style={{cursor:'pointer',fontSize:24,color:'grey'}}
    /> :
    <div style={{color:'#8f9192'}}>{`Days ${p.range}`}</div>}
  </ProtocolWrap>
}

const BlueBox = styled.div`
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background:#f6fbfc;
  width:100%;
  border-radius:10px;
  min-height:300px;
  padding:16px;
`
const ProtocolWrap=styled.div`
  border-radius:8px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  margin:10px;
  background:white;
  padding: 8px 16px;
  font-size:17px;
  min-height:48px;
`
const ProtocolLeft=styled.div`
  display:flex;
  align-items:center;
  justify-content:center;
`
const NewProtocol=styled.div`
  border-radius:8px;
  border:2px dashed #0a99b8;
  display:flex;
  align-items:center;
  justify-content:center;
  margin:10px;
  background:transparent;
  padding: 8px 16px;
  font-size:17px;
  min-height:48px;
  color:#0a99b8;
  cursor:pointer;
  &:hover{
    color:#055e6c;
    border-color:#055e6c;
  }
`

function getRandomArbitrary(min, max) {
  return Math.random() * (max - min) + min;
}