import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import {patient,patientProcedure,patientDevices} from '../form/schema'
import styled from 'styled-components'
import { Button, Title, BigTitle, Shadow} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { post } from '../../provider/api'
import { useRom } from '../../provider/rom'
import EE from '../utils/events'
import * as Yup from "yup";
import {icd10} from "../form/icd10";

const PatientInformation = (props) => {
    const patientID = parseInt(props.computedMatch.params.patientID)
    console.log(patientID)

    const rom = useRom()
    const {ui} = rom
    const {roles,user} = ui

    const SP = {
        address: [],
        dme: "1",
        date_of_birth: "12101988",
        email: "asd@asd.com",
        first_name: "sdfg",
        id: 19,
        last_name: "sdfg",
        phone_number: {
            id: 46, 
            number: "2342342342",
            name: "Home Phone"
        },
        physical_therapist_id: "1",
        surgeon_id: "1",
    }

    const [renderForm, setRenderForm] = useState(true)
    const [initialValues, setInitialValues] = useState({})
    const [step, setStep] = useState(0)
    const [selectedPatient, setSelectedPatient] = useState(SP)
    const [submitting, setSubmitting] = useState(null)
    const history = useHistory()

    useEffect(()=>{
        EE.on('fill-address',(e)=>{
            console.log('fill address',e)
            let updates = {...e}
            setInitialValues(updates)
            refreshForm()
        })
    })

    function refreshForm(){
        setRenderForm(false)
        setTimeout(()=>{
            setRenderForm(true)
        },20)
    }
    
    const aButtons = [
        {type:'cancel','text':'Cancel'},
        {type:'submit','text':'Save',color:'secondary'},
    ]
    const bButtons = [
        {type:'cancel','text':'Cancel'},
        {type:'submit','text':'Save',color:'secondary'},
    ]
    const cButtons = [
        {type:'cancel','text':'Cancel'},
        {type:'submit','text':'Save',color:'secondary'},
    ]

    async function saveProcedure(v){

        console.log("saveProcedure v values");
        console.log(v);
        // console.log("saveProcedure v.procedureLeg");
        // console.log(Object.getOwnPropertyNames(v.procedureLeg));
        // procedureLeg: {label: "Right", name: "right", id: "1"}

        const proceduredata = {
            "is_default":  0,
            "procedure_name": v.procedure, // "C00-D49",
            "procedure_leg": v.procedureLeg["name"],
            "pimary_diagnosis_icd10": v.diagnosis.id,
            "procedure_date":  v.proceduredate[0]+"/"+v.proceduredate[1]+"/"+v.proceduredate[2],
            "treatment_start_date":  v.treatmentStartDate[0]+"/"+v.treatmentStartDate[1]+"/"+v.treatmentStartDate[2]

        }

        setSubmitting(true)

        try{

            const ppd = await post('patient_procedure',proceduredata)
            console.log('ppd',ppd)

            setStep(1)

        } catch(e){
            console.log('e',e)
        }

        setSubmitting(false)
    }

    async function saveDevices(d){

        // ERRORS response"success":false,"data":{"validation_errors":{"device_type_id":["This is required."],"mac_address":["This is required."],"serial_number":["This is required."]}}}
        //{"success":false,"data":{"validation_errors":{"patient_device":{"patient_id":["This patient id does not exist."],"device_id":["This is required."]},"device":{"device_type_id":["This is required."],"mac_address":["This is required."],"serial_number":["This is required."]}}}}
        // server api error:  {"success":false,"data":"count(): Parameter must be an array or an object that implements Countable"}
        const devicePatientdata = {
            "patient_id" : 1, //"practice_id": user&&user.id,
            "device_id": 1,
            "device_type_id":   1,  // What is the device id selected ???? // TODO
            "mac_address":      1,  //    d.mac_address,
            "serial_number":    1, //   d.mac_address,
            "is_default":       0
        }

        console.log("testing devicePatientdata data",devicePatientdata);

        //map devices, add each

        // autocomplete search for serial number
        
        //patient device add, send patient id and device id

        //use placeholder data for now? get some real examples of devices

        setSubmitting(true)

        try{
            const p = await post('patient_device',devicePatientdata)

            console.log('p',p)

            setStep(2)

/*
            const pd = await post('patientdevice',devicePatientdata)

            console.log('pd',pd)

            setStep(2)*/


        } catch(e){
            console.log('e',e)
        }

        setSubmitting(false)
    }

    async function createPatient(f){

        const oP = f.home_phone
        let oPFormatted = oP&&''+oP['0']+oP['1']+oP['2']
        const mP = f.mobile_phone
        let mPFormatted = mP&&''+mP['0']+mP['1']+mP['2']
        const dob = f.date_of_birth
        let dobFormatted = dob&&''+dob['0']+dob['1']+dob['2']

        const data = {

            "user_id": user&&user.id,  //where is the user id stored???? // TODO
            "first_name": f.first_name,
            "last_name": f.last_name,
            "surgeon_id": f.surgeon,
            "physical_therapist_id": f.pt,
            "date_of_birth":  dobFormatted?dobFormatted:'',
            //"dob": dobFormatted[0]+"/"+dobFormatted[1]+"/"+dobFormatted[2],
            "dme": 1,
            "email": f.email||'',
            'address': {
                "line_1" : f.line_1||'',
                "city" : f.city||'',
                "state" : f.state||'',
                "zip_code" : f.zip_code||''
            },
           /* "phone_number":[
                {
                    "is_default": 0,
                    "name": "Home Phone",
                    "number": oPFormatted?oPFormatted:''
                },
                {
                    "is_default": 0,
                    "name": "Mobile Phone",
                    "number": mPFormatted?mPFormatted:''
                }
            ]*/
        }

        console.log('data',data)

        try{
            setSubmitting(true)
            const p = await post('patient',data)
            console.log('p',p)
            setSelectedPatient(p)
            setStep(1)
            // alert('success!')
            // history.push('/search')
        } catch(e){
            console.log('e',e)
        }

        setSubmitting(false)
       
    }

    const tabButtons = [
        {
            type:'util',
            color:'sea',
            text:'Patient',
            func:()=>setStep(0)
        },
        {
            type:'util',
            color:'sea',
            text:'Procedure',
            func:()=>setStep(1),
            dead:!selectedPatient
        },
        {
            type:'util',
            color:'sea',
            text:'Devices',
            func:()=>setStep(2),
            dead:!selectedPatient
        },
    ]

    return (<Wrap>
            <Title title={'Patient Information'}/>

            <ButtonRow>
                <Shadow>
                    {tabButtons.map((b,i)=>{
                        return <Button
                        type={b.type}
                        text={b.text} key={i}
                        invert={step!==i}
                        dead={b.dead}
                        color={b.color}
                        style={{margin:0,width:171}}
                        onClick={()=>b.func()}
                        />
                    })}
                </Shadow>
            </ButtonRow>

            {step === 0 ?
            <>
                {renderForm&&
                <Form
                    config={patient}
                    submitting={submitting}
                    initialValues={initialValues}
                    buttons={aButtons}
                    inputWidth={386}
                    formStyle={{flexWrap:'wrap',flexDirection:'row',justifyContent:'space-between',width:1238}}
                    onSubmit={(v)=>{
                        createPatient(v)
                    }}
                    onCancel={()=>history.push('/patients')}
                />}
            </>
            :step === 1 ?
            <Form
                config={patientProcedure}
                submitting={submitting}
                buttons={bButtons}
                inputWidth={386}
                formStyle={{flexWrap:'wrap',flexDirection:'row',justifyContent:'space-between',width:1238}}
                onCancel={()=>setStep(1)}
                onSubmit={(v)=>{
                    saveProcedure(v)
                }}
            />
            :
            <Form
                config={patientDevices}
                submitting={submitting}
                buttons={cButtons}
                inputWidth={386}
                onCancel={()=>setStep(2)}
                onSubmit={(v)=>{
                    saveDevices(v)
                }}
            />
            }

    </Wrap>);
}

export default PatientInformation

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    align-content:center; 
`

const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:30px;
`

