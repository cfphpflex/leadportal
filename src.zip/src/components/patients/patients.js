import React, { useState, useEffect, useCallback, useContext } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle,Input, SubTitle, Select, Shadow} from '../ui/romUI'
import ItemList from '../lists/itemList'
import Devices from '../devices/devices'
import { patientsHeaders } from '../listHeaders'
import { patients } from '../fakeData'
import * as api from "../../provider/api";
import {useRom} from "../../provider/rom";
import moment from "moment";

const Patients = (props) => {
    const rom = useRom()
    const {ui, setUI} = rom

    const [mode, setMode] = useState('patientsItems')
    const [filters, setFilters] = useState({
        pts:{label:'All Physical Therapists',name:'allPTA'},
        surgeons:{label:'All Surgeons',name:'allS'},
        dmes:{label:'All DMEs',name:'allD'},
        procedures:{label:'All Procedures',name:'allP'},
    })

    const tabButtons = [
        {
            type:'util',
            color:'sea',
            text:'Patients',
        },
        {
            type:'util',
            color:'sea',
            text:'Devices',
        }
    ]

    const dropdowns = [
        {
            label:'Physical Therapists',
            name:'pts',
            type:'select',
            options:[
                {label:'All Physical Therapists',name:'allPTA'},
                {label:'Some',name:'specialist'},
                {label:'Other',name:'other'}]
        },
        {
            label:'Surgeons',
            name:'surgeons',
            type:'select',
            options:[
                {label:'All Surgeons',name:'allS'},
                {label:'Some',name:'specialist'},
                {label:'Other',name:'other'}]
        },
        {
            label:'DMEs',
            name:'dmes',
            type:'select',
            options:[
                {label:'All DMEs',name:'allD'},
                {label:'Some',name:'specialist'},
                {label:'Other',name:'other'}]
        },
        {
            label:'Procedures',
            name:'procedures',
            type:'select',
            options:[
                {label:'All Procedures',name:'allP'},
                {label:'Some',name:'specialist'},
                {label:'Other',name:'other'}]
        }
    ]

    const patientsItems = new Object();

    useEffect(()=>{
        setTimeout(()=>{
            // wait for ui to fill with token
            getData()
        },500)
    },[])
    async function getData(){
        console.log('start getting data')
        let patients = []

        const p = await api.post('patient/query')
        if (p&&p.results) patients = p.results
        console.log('patients',patients)

           /* name:'L, Robert',
            pt:'John Smith',
            age:'71',
            email:'hi@hotmail.com',
            dme:'-',
            surgeon:'Michelle Jones',
            procedure:'Knee Replacement (L)',
            procedureDate:moment().format('llll'),
            postOpDay:3,
            pain:6,
            romExtF:23,
            flexion:102,
            sessionCompTot:'18/83',
            lastSession:moment().format('llll'),
            alerts:[],
            id:34,
            pcSerial:'f3748q474fga478',
            aaSerial:'afw87gawfggoia',
            asSerial:'aw7afw9b87af',
            location:'Olympia, WA',
            daysRemaining:10*/

        patients.forEach((n)=>{
            {
                patientsItems['name'] = n['first_name']
                patientsItems['pt'] = n['last_name']
                patientsItems['age'] = "18"
                patientsItems['email'] = n['email']
                patientsItems['dme'] = '-'
                patientsItems['surgeon'] = 'Michelle Jones'
                patientsItems['procedure'] = 'Knee Replacement (L)'
                patientsItems['procedureDate'] = moment().format('llll')
                patientsItems['postOpDay'] = 3
                patientsItems['pain'] = 6
                patientsItems['romExtF'] = 23
                patientsItems['flexion'] = 102
                patientsItems['sessionCompTot'] = '18/83'
                patientsItems['lastSession'] = moment().format('llll')
                patientsItems['alerts'] = []
                patientsItems['id'] = 34
                patientsItems['pcSerial'] = 'f3748q474fga478'
                patientsItems['aaSerial'] = 'afw87gawfggoia'
                patientsItems['asSerial'] = 'aw7afw9b87af'
                patientsItems['location'] = 'Olympia, WA'
                patientsItems['daysRemaining'] = 10
            }

           /* patientsItems['p.fname'] = n['first_name']
            patientsItems['p.lname'] = n['last_name']
            patientsItems['p.surgeonID'] = n['surgeon_id']
            patientsItems['p.physicaltherapist_id'] = n['physical_therapist_id']
            patientsItems['p.date'] = n['dob']
            patientsItems['p.dme'] = n['dme']
            patientsItems['p.mail'] = n['email']
            patientsItems['p.add'] = "New york"
            patientsItems['p.phone'] = "1234567890"


            patientsItems['date'] = 'My cool template'
            patientsItems['isDefault'] = true*/

        })

        console.log('two patientsItems data')
        console.log(patientsItems)
        console.log('end patient data')
        console.log(patients)
        //setUI({patients})
        console.log('end patient2 data')
        console.log(patientsItems)
    }

    const isPatients = mode==='patientsItems'

    return (<Wrap>
            <Title title={isPatients?'Patients':'Devices'}/>

            {/* <ButtonRow>
                <Shadow>
                    {tabButtons.map((b,i)=>{
                        return <Button
                        type={b.type}
                        text={b.text} key={i}
                        invert={mode!==b.text}
                        color={b.color}
                        style={{margin:0,width:171}}
                        onClick={()=>setMode(b.text)}
                        />
                    })}
                </Shadow>
            </ButtonRow> */}

<div style={{display:'flex',flexDirection:'column'}}>
{isPatients?
        <>
            <div style={{width:'100%',display:'flex',justifyContent:'flex-start'}}>

            <div style={{width:'100%',display:'flex',justifyContent:'flex-start'}}>
                <SelectRow>
                    <div style={{display:'flex',justifyContent:'center',paddingTop:20,fontSize:16,marginRight:20}}>
                        Filters:
                    </div>
                    {dropdowns.map((d,i)=>{
                        return <div style={{marginRight:20}}>
                            <Select
                             style={{width:249}}
                            hideLabels
                            {...d}
                            value={filters[d.name]}
                            onBlur={(e)=>console.log('blur',e)}
                            onChange={(e)=>{
                                console.log('e',e)
                                setFilters({...filters,[d.name]:e})
                            }}
                        />
                    </div>
                    })}
                </SelectRow>
            </div>
            </div>

            <div style={{padding:50,paddingTop:20}}>
                <ItemList
                items={patients}
                headers={patientsHeaders}
                camera/>
            </div>
        </> : <Devices />
}
</div>
    </Wrap>);
}

export default Patients

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    ${'' /* align-content:center;  */}
    align-items:center; 
`
const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:30px;
`

const SelectRow = styled.div`
    display:flex;
    justify-content:space-between;
    align-content:center; 
    width:880px;
    margin-left:50px;
`
