import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import { patient, patientProcedure, patientDevices } from '../form/schema'
import styled from 'styled-components'
import { Button, Input, BigTitle, Detail, Select } from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { patients, chartData } from '../fakeData'
import PatientPanel, {BigPanel, SmallPanel, PanelHead} from './shared/patientPanel'
import TopRow from './shared/topRow'
// import * as api from '../../provider/api'
// import Select from '../utils/select'
import {templates,patientNotes,emptyProtocol} from '../fakeTreatmentData'
import ReorderProtocols from './reorderProtocols'
import ProtocolBox from './shared/protocolBox'
import PatientNotes from './patientNotes'
import {useRom} from '../../provider/rom'

const treatmentPlanOptions = templates

const TreatmentPlan = (props) => {
  const rom = useRom()
  const {setState,notes} = rom

  let isNew = false
  let patientID = 0
  const idParam = props.computedMatch.params.patientID
  if (idParam==='new') {
    isNew = true
  } else {
    patientID = parseInt(idParam)
  }

  const [submitting, setSubmitting] = useState(null)
  const [selectedTreatmentPlanID, setSelectedTreatmentPlanID] = useState(1) // start with first one selected
  const [name, setName] = useState('')
  const [cachedName, setCachedName] = useState('')
  const [editing, setEditing] = useState(false)
  const [protocols, setProtocols] = useState([])
  const [cachedProtocols, setCachedProtocols] = useState([])
  const [activeTreatmentPlanID, setActiveTreatmentPlanID] = useState(1)  

  const plan = treatmentPlanOptions.find(o=> o.id===selectedTreatmentPlanID)

  const history = useHistory()

  useEffect(()=>{
    (async()=>{
      // load async stuff here
    })()
  },[])

  useEffect(()=>{
    if(!isNew) {
      if(plan.protocols) {
        setProtocols(plan.protocols)
        setCachedProtocols([])
        setName(plan.label)
        setCachedName('')
      }
    } else {
      setProtocols([emptyProtocol])
      setName('New Template')
      setEditing(true)
    }
  },[selectedTreatmentPlanID])

  useEffect(()=>{
    setState({notes:patientNotes})
  },[])

  async function save(){
    setSubmitting(true)
    await sleep(1000)
    setSubmitting(false)
    setEditing(false)
  }

  const patient = patients.find(p=>p.id===patientID)
  if(!isNew && !patient) {
    return <NotFound>Patient Not Found</NotFound>
  }

  // console.log("PATIENT DATA", patient)

  function startEditing(){
    setCachedProtocols(protocols)
    setCachedName(name)
    setEditing(true)
  }
  function cancelEditing(){
    setProtocols(cachedProtocols)
    setEditing(false)
    setName(cachedName)
  }

  function changeProtocol(np){
    if(np.id) {
      const theProtocols = [...protocols]
      const pi = theProtocols.findIndex(p=> p.id===np.id)
      theProtocols[pi] = np
      setProtocols(theProtocols)
    }
  }

  return (<Wrap>

    <TopRow label="Treatment Plan" backLabel="Patient Profile" 
      backAction={()=> history.push(`/patientProfile/${patientID}`)}
    />

    {!isNew && 
      <PatientPanel patient={patient} hideButton="Manage Treatment Plan" />
    }

    {plan && <BigPanel style={{display:'flex'}}>
      <Half style={{marginRight:24}}>
        {!editing && <PlanTitle>{plan.label}</PlanTitle>}
        {editing && <div style={{height:85}}>
          <FieldLabel htmlFor="Treatment Plan">Treatment Plan</FieldLabel>
          <Input label="Treatment Plan" 
            value={name} onChange={e=> setName(e.target.value)}
          />
        </div>}
        <PatientNotes notes={notes} addNote={n=>{
          setState({notes:[...notes,n]})
        }}/>
      </Half>
      <Half>
        <EditButtons save={save} submitting={submitting} editing={editing}
          start={startEditing} cancel={cancelEditing}
          active={selectedTreatmentPlanID===activeTreatmentPlanID}
          activate={()=>setActiveTreatmentPlanID(selectedTreatmentPlanID)}
        />
        <Select label="Treatment Plan" options={treatmentPlanOptions}
          value={selectedTreatmentPlanID}
          style={{width:'100%'}}
          onChange={e=> setSelectedTreatmentPlanID(e.id)}
          disabled={editing}
        />
        <ReorderProtocols protocols={protocols} setProtocols={setProtocols} editing={editing} />
      </Half>
    </BigPanel>}

    {protocols && protocols.map((p,i)=>{
      return <ProtocolBox key={i} active={i===0} index={i} 
        protocol={p} protocols={protocols} editing={editing} 
        changeProtocol={changeProtocol}
      />
    })}

  </Wrap>)
}

function EditButtons({editing,cancel,start,save,submitting,activate,active}){
  return <>
    {!editing?<Row style={{width:'100%'}}>
      <Button
        color="submit" text="Edit Plan"
        onClick={start}
        style={{width:'49%',margin:'0 15px 15px 0'}}
      />
      {active ? <NotAButton>Active</NotAButton> : <Button
        color="submit" text="Activate Plan" submitting={submitting}
        onClick={()=> activate()}
        style={{backgroundColor:'#01b2cf',width:'49%',margin:'0 15px 15px 0'}}
      />}
    </Row> : <Row>
      <Button
        color="save" text="Cancel Changes"
        onClick={cancel}
        style={{width:'49%',margin:'0 15px 15px 0'}}
      />
      <Button
        color="submit" text="Save" submitting={submitting}
        onClick={()=> save()}
        style={{width:'49%',margin:'0 15px 15px 0'}}
      />
    </Row>}
  </>
}

export default TreatmentPlan

const Wrap = styled.div`
  display:flex;
  flex:1;
  min-width:1300px;
  max-width:3000px;
  position:relative;
  flex-direction:column;
  ${'' /* justify-content:center; */}
  align-content:center; 
`
const WrapRow=styled.div`
  display:flex;
  justify-content:space-between;
  flex-wrap:wrap;
  width:1348px;
`
const Row=styled.div`
  display:flex;
  justify-content:space-between;
`
const Half=styled.div`
  width:50%;
`

const Session = styled.div`
  width:20%;
  display:flex;
  flex-direction:column;
  align-items:center;
  padding:4px;
`
const PeriodLabel=styled.div`
  display:flex;
  justify-content:center;
  align-items:center;
  width: 100%;
  height: 50px;
  font-family: Montserrat;
  font-size: 18px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.22;
  letter-spacing: normal;
  text-align: center;
  text-transform: none;
  border-width: 2px;
  border-style: solid;
  border-radius: 10px;
`
const NotFound = styled.div`
  flex:1;
  display:flex;
  align-items:center;
  justify-content:center;
`
export const PlanTitle = styled.div`
  font-size: 27px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.22;
  letter-spacing: normal;
  text-align: left;
  color: #206c79;
  height:70px;
  padding-top:11px;
  border-bottom:2px solid #0a99b8;
  display: flex;
  align-items: flex-start;
`
const NotAButton=styled.div`
  width: 49%;
  margin: 0px 15px 15px 0px;
  height: 50px;
  border-radius: 10px;
  color: rgb(255, 255, 255);
  font-family: Montserrat;
  font-size: 18px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.22;
  letter-spacing: normal;
  text-align: center;
  text-transform: none;
  background-color: #76b647;
  display:flex;
  align-items:center;
  justify-content:center;
`
const FieldLabel = styled.label`
  font-weight: thin;
  color: #666666;
  font-size: 16px;
  font-weight:500;
`

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))