import React, {useState} from 'react'
import styled from 'styled-components'
import { Button, Image, Detail } from '../../ui/romUI'
import MaterialIcon from '@material/react-material-icon';
import { useHistory } from "react-router-dom";

const pData = [
  { name: 'pt', label: 'Personal Therapist' },
  { name: 'dme', label: 'DME' },
  { name: 'dob', label: 'DOB' },
  { name: 'phone', label: 'Phone' },
  { name: 'surgeon', label: 'Surgeon' },
  { name: 'id', label: 'Patient ID' },
  { name: 'age', label: 'Age' },
  { name: 'email', label: 'Email' }
]
const headButtons = [
  {
    label: 'RomTime',
    type: 'third',
    path: 'romTime',
    image: 'cameraWhite'
  },
  // {
  //   label: 'Message',
  //   type: 'third',
  //   path: 'messaging'
  // },
  {
    label: 'Manage Treatment Plan',
    type: 'third',
    path: 'treatmentPlan',
    image: 'gear'
  },
]
const buttonColors=[
  '#01b2cf',
  // '#0a99b8',
  '#065d6b'
]

export default function PatientPanel({patient,hideButton}) {
  const [showDrawer, setShowDrawer] = useState(false)
  const history = useHistory()

  return <BigPanel>
    <div style={{ display:'flex', justifyContent:'space-between' }}>
      <div>
        <div style={{display:'flex'}}>
          <PanelHead style={{textAlign:'left',width:'auto'}}>
            {patient.name}
          </PanelHead>
          <Image source={'/static/pencil.png'} style={{height:28,width:28,marginLeft:15,cursor:'pointer'}} 
            onClick={()=> history.push(`/patientInformation/${patient.id}`)}
          />
        </div>
        <div style={{marginTop:8}}>
          <Info>{`Serial Number: ${patient.pcSerial}`}</Info>
          <Info>{`Treatment Start Date: ${patient.treatmentStartDate}`}</Info>
        </div>
      </div>
      <div style={{display:'flex',alignItems:'center'}}>
        {headButtons.filter(b=>b.label!==hideButton).map((b, i) => {
          return <Button
            key={i}
            text={b.label}
            type={b.type}
            image={`/static/${b.image}.png`}
            style={{
              background:buttonColors[i],padding:'2px 6px',
              width:'auto',
              padding:'0px 18px'
            }}
            onClick={()=> history.push(`/${b.path}/${patient.id}`)}
          />
        })}
        <MaterialIcon icon={showDrawer?'expand_less':'expand_more'} 
          onClick={()=>setShowDrawer(!showDrawer)}
          style={{cursor:'pointer',fontSize:60,color:'#0a99b8'}}
        />
      </div>
    </div>

    {showDrawer && <Drawer>
      <div style={{ display: 'flex', flex: 1, flexWrap: 'wrap', justifyContent: 'space-between' }}>
        {pData.map((d, i) => {
          return <Detail key={i} label={d.label} style={{ width: 300,marginBottom:20 }} name={patient[d.name]} />
        })}
      </div>
    </Drawer>}
  </BigPanel>
}

export const BigPanel = styled.div`
  width: 1348px;
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background-color: #ffffff;
  margin-bottom:30px;
  padding: 20px 40px;
`
export const SmallPanel = styled.div`
  width: 659px;
  height: 209px;
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background-color: #ffffff;
  margin-bottom:30px;
  padding: 20px 40px;
`
const Drawer = styled.div`
  display:flex;
  flex:1;
  padding:30px 0 0 0;
`
export const PanelHead = styled.div`
  width:100%;
  font-size: 27px;
  border-radius: 10px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.22;
  letter-spacing: normal;
  text-align: left;
  color: #0899b7;
`
const Info = styled.div`
  font-size: 14px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.00;
  letter-spacing: 0.32px;
  text-align: left;
  color: #055e6c;
  margin-bottom:4px;
`