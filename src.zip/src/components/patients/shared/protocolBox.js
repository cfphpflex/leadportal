import React, { useState, useEffect, useCallback, useContext } from 'react'
import styled from 'styled-components'
import {BigPanel} from './patientPanel'
import EditingProtocolBox from './editingProtocolBox'

// protocol > session > period
const periodColors={
  assisted:'#01b2cf',
  active:'#0a99b8',
  resistance:'#065d6b',
}

export default function ProtocolBox({active,protocol,index,protocols,editing,changeProtocol}){
  if(editing) {
    return <EditingProtocolBox protocol={protocol} changeProtocol={changeProtocol} />
  }
  const {range, label, periods, sessionNum} = protocol
  let startDay = 1
  const previousProtocols = protocols.filter((p,i)=>i<index)
  previousProtocols.forEach(p=>{
    startDay+=p.daysNum
  })
  const endDay = startDay+protocol.daysNum-1
  return <BigPanel style={active?{border:'2px solid #0899b7'}:{}}>
    <Row>
      <H2 style={{color:'#7a7b7e'}}>{`DAYS ${startDay}-${endDay}`}</H2>
      <H2 style={{textAlign:'center'}}>{`Protocol ${index+1}: ${label}`}</H2>
      <H2 style={{color:'#7a7b7e',textAlign:'right'}}>{`${sessionNum} SESSIONS PER DAY`}</H2>
    </Row>
    <Row style={{marginTop:10}}>
      {periods && periods.map((p,i)=>{
        return <Session key={i} style={{width:`${100/periods.length}%`}}>
          <PeriodLabel style={{
            borderColor:periodColors[p.type],
            color:periodColors[p.type],
          }}>
            {p.type.toUpperCase()}
          </PeriodLabel>
          <div style={{fontWeight:'bold',marginTop:10}}>{`${p.minutes} mins.`}</div>
          <div style={{color:'grey'}}>{p.direction}</div>
        </Session>
      })}
    </Row>
  </BigPanel>
}

const Row=styled.div`
  display:flex;
  justify-content:space-between;
`

const H2 = styled.div`
  font-size: 22px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.22;
  letter-spacing: normal;
  text-align: left;
  color: #0899b7;
  min-width:275px;
`
const Session = styled.div`
  width:20%;
  display:flex;
  flex-direction:column;
  align-items:center;
  padding:4px;
`
const PeriodLabel=styled.div`
  display:flex;
  justify-content:center;
  align-items:center;
  width: 100%;
  height: 50px;
  font-family: Montserrat;
  font-size: 18px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.22;
  letter-spacing: normal;
  text-align: center;
  text-transform: none;
  border-width: 2px;
  border-style: solid;
  border-radius: 10px;
`