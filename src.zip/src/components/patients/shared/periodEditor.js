import React, {useCallback} from 'react'
import styled from 'styled-components'
import PeriodBox from './periodBox'
import update from 'immutability-helper'
import {Button} from '../../ui/romUI'

const periodColors={
  assisted:'#01b2cf',
  active:'#0a99b8',
  passive:'#0a99b8',
  resistance:'#065d6b' , 
}
const periodTypes = [
  'Assisted','Active','Passive','Resistance'
]

export default function PeriodEditor({periods,changePeriods}){

  const movePeriod = useCallback(
    (dragIndex, hoverIndex) => {
      const dragCard = periods[dragIndex]
      const newPeriods = update(periods, {
        $splice: [
          [dragIndex, 1],
          [hoverIndex, 0, dragCard],
        ],
      })
      changePeriods(newPeriods)
    },
    [periods],
  )

  function changePeriod(np){
    if(np.id) {
      const thePeriods = [...periods]
      const pi = thePeriods.findIndex(p=> p.id===np.id)
      thePeriods[pi] = np
      changePeriods(thePeriods)
    }
  }
  function removePeriodById(id){
    if(!id) return
    const thePeriods = periods.filter(p=>p.id!==id)
    changePeriods(thePeriods)
  }
  function addPeriod(type){
    const thePeriods = [...periods]
    thePeriods.push({
      id:getRandomArbitrary(100,10000),
      type:type.toLowerCase(),
      minutes:5,
      direction:'Forward'
    })
    changePeriods(thePeriods)
  }

  return <Wrap>
    <Periods>
      {periods.map((p,i)=>{
        return <PeriodBox key={p.id} i={i}
          period={p}
          move={movePeriod}
          changePeriod={changePeriod}
          removePeriodById={removePeriodById}
        />
      })}
    </Periods>
    <Bottom>
      <AdderLabel>
        ADD to protocol or rearrange by clicking and dragging. Delete by clicking the "X".
      </AdderLabel>
      <PeriodButtons>
        {periodTypes && periodTypes.map((p,i)=>{
          const color = periodColors[p.toLowerCase()]
          return <Button key={i} 
            icon="add" iconStyle={{marginRight:12,marginLeft:-5}}
            type="util"
            text={p.toUpperCase()}
            invert={true}
            style={{color,border:`2px solid ${color}`,width:171,margin:3,fontSize:14,height:48}}
            color="sea"
            onClick={()=>addPeriod(p)}
          />
        })}
      </PeriodButtons>
    </Bottom>
  </Wrap>
}

const Wrap = styled.div`
  width:100%;
  display:flex;
  flex-direction:column;
  align-items:center;
`
const Periods = styled.div`
  width:1040px;
  display:flex;
  align-items:center;
  flex-wrap:wrap;
`
const Bottom=styled.div`
  display:flex;
  align-items:center;
  justify-content:center;
  flex-direction:column;
  margin-top:20px;
`
const PeriodButtons=styled.div`
  display:flex;
  align-items:center;
  justify-content:center;
`
const AdderLabel=styled.div`
  width:100%;
  display:flex;
  justify-content:center;
  align-items:center;
  color:grey;
  margin-bottom:12px;
`

function getRandomArbitrary(min, max) {
  return Math.random() * (max - min) + min;
}