import React, {useState,useEffect} from 'react'
import styled from 'styled-components'
import CompoundSlider from '../../ui/compoundSlider'
import {BigPanel} from './patientPanel'
import { Button, Input, Select } from '../../ui/romUI'
import PeriodEditor from './periodEditor'

const sliders = [{
  label:'Pedal Radius Adjustment',
  name:'pedalRadius',
  min:1,max:6,
  prefix:"A",
  single:true,
},{
  label:'Resistance',
  name:'resistance',
  min:1,max:10,
  single:true,
},{
  label:'RPM',
  name:'rpm',
  min:0,max:80,
},{
  label:'Pressure Limit',
  name:'pressureLimit',
  sub:"* For patient's with approximate weight of 250lbs *",
  min:0,max:50,
  single:true,
}]

const numberOfDays = Array.from(Array(30).keys())
const numberOfSessions = Array.from(Array(10).keys())
const inputs = [{
  label:'Protocol Name',
  name:'label',
  type:'text',
},{
  label:'Protocol Purpose',
  name:'purpose',
  type:'text',
},{
  label:'Number of Days',
  name:'daysNum',
  type:'select',
  options:numberOfDays.map(n=>(
      {label:n+1, name:n+1, id:n+1}
  ))
},{
  label:'Sessions per Day',
  name:'sessionsNum',
  type:'select',
  options:numberOfSessions.map(n=>(
      {label:n+1, name:n+1, id:n+1}
  ))
}]

const tabButtons=['Left','Right','Bilateral']

export default function EditingProtocolBox({protocol,changeProtocol}){
  const {label, periods, sessionNum} = protocol
  const [sliderValues, setSliderValues] = useState({})
  const [inputValues, setInputValues] = useState({})
  const [leg,setLeg] = useState('Left')

  useEffect(()=>{
    setInputValues({
      label:protocol.label,
      purpose:protocol.purpose,
      sessionNum:{label:protocol.sessionNum,name:protocol.sessionNum},
      daysNum:{label:protocol.daysNum,name:protocol.daysNum},
    })
  },[])

  function changePeriods(periods){
    changeProtocol({...protocol,periods})
  }

  return <BigPanel>
    <Inner>
      <Top>
        <ButtonRow>
          <Shadow>
            {tabButtons.map((b,i)=>{
              return <Button key={i}
                type="util"
                text={b} key={i}
                invert={leg!==b}
                color="sea"
                style={{margin:0,width:171}}
                onClick={()=>setLeg(b)}
              />
            })}
          </Shadow>
        </ButtonRow>
      </Top>
      <Middle>
        <Section>
          {inputs.map((input,i)=>{
            const El = input.type==='text'?Input:Select
            return <div key={i}>
              {input.type==='text' && <FieldLabel htmlFor={input.label}>{input.label}</FieldLabel>}
              <El value={inputValues[input.name]||''} label={input.label}
                options={input.options}
                onChange={e=> {
                  let value = input.type==='text'?e.target.value:e
                  setInputValues({...inputValues, [input.name]:value})
                }} 
              />
            </div>
          })}
        </Section>
        <Section>
          {sliders.map((s,i)=>{
            return <div key={i} style={{marginBottom:10}}>
              <CompoundSlider key={i}
                label={s.label}
                prefix={s.prefix}
                subtitle={s.sub}
                onChange={(e)=>{
                  setSliderValues({...sliderValues, [s.name]:e})
                }}
                value={sliderValues[s.name]}
                min={s.min} max={s.max} single={s.single} 
              />
            </div>
          })}
        </Section>
      </Middle>
      <Bottom>
        <PeriodEditor periods={periods} changePeriods={changePeriods} />
      </Bottom>
    </Inner>
  </BigPanel>
}

const Inner=styled.div`
  margin:25px;
  display:flex;
  flex-direction:column;
  align-items:center;
`
const Middle=styled.div`
  display:flex;
  align-items:center;
  justify-content:space-between;
  width:100%;
`
const Bottom=styled.div`
  display:flex;
  align-items:center;
  justify-content:space-between;
  width:100%;
  margin-top:22px;
`
const Section=styled.div`
  width:50%;
  display:flex;
  flex-direction:column;
  align-items:center;
`
const Top=styled.div`
  width:100%;
  display:flex;
  align-items:center;
  justify-content:center;
`
const ButtonRow = styled.div`
  display:flex;
  justify-content:center;
  align-content:center; 
  margin-bottom:30px;
`
const Shadow = styled.div`
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.15);
`
const FieldLabel = styled.label`
  font-weight: thin;
  color: #666666;
  font-size: 16px;
  font-weight:500;
`