import React, {useRef} from 'react'
import styled from 'styled-components'
import MaterialIcon from '@material/react-material-icon';
import { useDrag, useDrop } from 'react-dnd'

const periodColors={
  assisted:'#01b2cf',
  active:'#0a99b8',
  passive:'#0a99b8',
  resistance:'#065d6b' , 
}
// #76b647 // green
export default function PeriodBox(props){
  const {i,period,changePeriod,removePeriodById} = props
  const {id,type,minutes,direction} = period
  const color = periodColors[type]

  const ref = useRef(null)
  const [, drop] = useDrop({
    accept: 'period',
    hover(item, monitor) {
      if (!ref.current) {
        return
      }
      const dragIndex = item.i
      const hoverIndex = i
      // Don't replace items with themselves
      if (dragIndex === hoverIndex) {
        return
      }
      // Determine rectangle on screen
      const hoverBoundingRect = ref.current.getBoundingClientRect()
      // Get vertical middle
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2
      // Get horizontal middle
      const hoverMiddleX = (hoverBoundingRect.right - hoverBoundingRect.left) / 2
      // Determine mouse position
      const clientOffset = monitor.getClientOffset()
      // Get pixels to the top
      const hoverClientY = clientOffset.y - hoverBoundingRect.top
      // Get pixels from the left
      const hoverClientX = clientOffset.x - hoverBoundingRect.left
      // Dragging downwards or left
      if (dragIndex < hoverIndex && (hoverClientY < hoverMiddleY && hoverClientX > hoverMiddleX)) {
        return // (this is not actually check the "halfway")
      }
      // Dragging upwards or right
      if (dragIndex > hoverIndex && (hoverClientY > hoverMiddleY && hoverClientX < hoverMiddleX)) {
        return // (this is not actually check the "halfway")
      }
      if(props.move) props.move(dragIndex, hoverIndex)
      item.i = hoverIndex
    },
  })

  const [{ isDragging }, drag] = useDrag({
    item: { i, id, type:'period' },
    collect: monitor => ({
      isDragging: monitor.isDragging()
    }),
  })
  const opacity = isDragging ? 0.2 : 1
  drag(drop(ref))

  function change(changes){
    changePeriod({...period,...changes})
  }
  function remove(){
    removePeriodById(id)
  }

  return <Wrap color={color} ref={ref} style={{opacity}}>
    <Top>
      <MaterialIcon icon="drag_indicator" style={{fontSize:24,color,cursor:'pointer'}} /> 
      <div style={{marginBottom:5,color,fontWeight:'bold'}}>{type.toUpperCase()}</div>
      <MaterialIcon icon="close" style={{fontSize:24,color,cursor:'pointer'}}
        onClick={()=> remove()}
      />
    </Top>
    <Bottom>
      <Row>
        <CircleIcon icon="remove" color={color} onClick={()=>change({minutes: period.minutes-1})} />
        <Label>{`${minutes} mins.`}</Label>
        <CircleIcon icon="add" color={color} onClick={()=>change({minutes: period.minutes+1})} />
      </Row>
      <Row>
        <CircleIcon icon="fast_rewind" color="#76b647" active={direction==='Backwards'} toggler 
          onClick={()=> {
            if(period.direction!=='Backwards') change({direction:'Backwards'})
          }}
        />
        <Label>{capitalize(direction)}</Label>
        <CircleIcon icon="fast_forward" color="#76b647" active={direction==='Forward'} toggler 
          onClick={()=> {
            if(period.direction!=='Forward') change({direction:'Forward'})
          }}
        />
      </Row>
    </Bottom>
  </Wrap>
}

function CircleIcon({color,active,toggler,icon,onClick}){
  let bg = color
  let iconColor = 'white'
  if(toggler) {
    if(!active) {
      bg = 'white'
      iconColor='grey'
    }
  }
  return <Circle background={bg} onClick={onClick} border={toggler&&!active}>
    <MaterialIcon icon={icon} style={{fontSize:23,color:iconColor}} />
  </Circle>
}

const Wrap = styled.div`
  width:200px;
  height:150px;
  border:2px solid ${p=> p.color};
  margin:4px;
  border-radius:10px;
  padding:12px;
  display:flex;
  flex-direction:column;
  justify-content:space-between;
  align-items:center;
`
const Circle=styled.div`
  width:30px;
  height:30px;
  min-width:30px;
  min-height:30px;
  user-select:none;
  border-radius:50%;
  background:${p=>p.background||'black'};
  border-color:#bababa;
  border-style:solid;
  border-width:${p=>p.border?'1px':'0'};
  display:flex;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  transition:transform 0.1s;
  transform-origin:center;
  &:hover{
    transform:scale(1.05,1.05);
  }
`
const Top=styled.div`
  width:100%;
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:8px;
`
const Bottom=styled.div`
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:space-between;
  width:100%;
`
const Row=styled.div`
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:0 9px;
  width:100%;
  margin-bottom:8px;
`
const Label=styled.div`
  font-weight:bold;
  min-width:94px;
  text-align:center;
`

const capitalize = (s) => {
  if (typeof s !== 'string') return ''
  return s.charAt(0).toUpperCase() + s.slice(1)
}