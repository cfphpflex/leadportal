import React from 'react'
import MaterialIcon from '@material/react-material-icon';
import { Button, Title, BigTitle, Detail } from '../../ui/romUI'
import styled from 'styled-components'

export default function TopRow({label,backLabel,backAction,hidePDF}){
  return <>
    <Title title={label} />
    <TopButtonRow>
      <Back onClick={()=>{
        if(backAction) backAction()
      }}>
        <MaterialIcon icon={'arrow_back'}
          style={{ marginRight: 10, fontSize: 26, color: '#106179' }}
        />
        <div>{backLabel}</div>
      </Back>
      {hidePDF?<div style={{ width: 200, alignSelf: 'top',margin:10,
    height: 50 }}/>:<Button
        type={'info'}
        icon={'print'}
        iconStyle={{ marginRight: 10 }}
        text={'Print PDF'}
        style={{ width: 200, alignSelf: 'top' }}
        onClick={() => console.log('print pdf')}
      />}
    </TopButtonRow>
  </>
}


const TopButtonRow = styled.div`
  display:flex;
  position:absolute;
  top:25px;
  left:0px;
  width:100%;
  justify-content:space-between;
  align-content:center; 
  margin-bottom:30px;
`

const Back = styled.div`
  display:flex;
  cursor:pointer;
  align-items:center;
  align-content:center;
  position:relative;
  font-size: 20px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.2;
  letter-spacing: normal;
  text-align: left;
  color: #797a7c;
`