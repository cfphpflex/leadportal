import React, {useState} from 'react'
import styled from 'styled-components'
import Chart from "../charts/chart";
import PatientPanel, {BigPanel, SmallPanel, PanelHead} from './shared/patientPanel'
import { patients, chartData, chartStyles, sessions } from '../fakeData'
import MaterialIcon from '@material/react-material-icon';

export default function TheChart({expanded,customColor,c,expandedChartTitle,setExpandedChartTitle}){
  const [selectedDay, setSelectedDay] = useState(null)
  const showPopover = selectedDay||selectedDay===0
  return <ChartPanel expanded={expanded}>
    <PanelHead>{c.title}</PanelHead>
    <Expander onClick={()=>{
      setExpandedChartTitle(
        c.title===expandedChartTitle?null:c.title
      )
    }}/>
    {showPopover && <Popover day={selectedDay} close={()=>setSelectedDay(null)}/>}
    <Chart data={injectChartStyles(chartData,c.title,expanded)}
      type={c.type} color={customColor} title={c.title}
      yLabel={c.yLabel} unit={c.unit} 
      onClick={e=> setSelectedDay(e._index+1)}
    />
  </ChartPanel>
}

function Popover({day,close}){
  return <PopoverWrap>
    <PopHead>{`Day ${day}`}</PopHead>
    <MaterialIcon icon={'close'} onClick={()=>close()} 
      style={{position:'absolute',fontSize:22,top:6,right:6,cursor:'pointer',color:'grey'}}
    />
    {sessions.map((s,i)=>{
      return <Session key={i}>
        <SessionTop>
          <SessionName>{`Session ${i+1}`}</SessionName>
          <SessionValue>{s.value}</SessionValue>
        </SessionTop>
        <SessionTime>{s.time}</SessionTime>
      </Session>
    })}
  </PopoverWrap>
}


export const differentStyles={
  Pain:{
    backgroundColor: "#db2835",
    borderColor: "#db2835",
    pointBackgroundColor: "#db2835",
    pointHoverBackgroundColor: "#db2835",
    pointHoverBorderColor: "#db2835",
  }
}
function injectChartStyles(data, title, expanded){
  const n = expanded?30:15
  const customStyles = differentStyles[title]||{}
  const datasets = data.datasets||[]
  const newDatasets = []
  datasets.forEach(ds=>{
    newDatasets.push({
      ...ds,
      ...chartStyles,
      ...customStyles,
    })
  })
  return {
    labels:nums(n),
    datasets:newDatasets
  }
}

function nums(l){
  return Array.from(Array(l).keys()).map(n=>n+1)
}

const ChartPanel = styled.div`
  width: ${p=>p.expanded?'1348':'659'}px;
  height: 355px;
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background-color: #ffffff;
  margin-bottom:30px;
  padding: 20px 40px;
  position:relative;
`
const Expander = styled.div`
  position:absolute;
  top:15px;
  right:15px;
  width:30px;
  height:30px;
  background:url(/static/expand.png);
  background-size: cover;
  cursor:pointer;
`
const PopoverWrap = styled.div`
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  width:180px;
  height:auto;
  background:white;
  position:absolute;
  left:10px;
  top:10px;
  border-radius:6px;
  padding-bottom:10px;
`
const PopHead = styled.div`
  width:100%;
  display:flex;
  justify-content:center;
  align-items:center;
  font-weight:bold;
  font-size: 20px;
  color:#0899b7;
  margin-top:5px;
`
const Session=styled.div`
  width:100%;
  padding:3px 12px;
`
const SessionTop=styled.div`
  display:flex;
  align-items:center;
  justify-content:space-between;
`
const SessionName=styled.div`
  font-size:16px;
`
const SessionValue=styled.div`
  font-size:16px;
  font-weight:bold;
`
const SessionTime=styled.div`
  color:#a7a7a7;
  font-size:12px;
`