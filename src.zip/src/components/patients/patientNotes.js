import React, {useState, useRef, useEffect} from 'react'
import styled from 'styled-components'
import { Button, Image, BigTitle, Detail } from '../ui/romUI'
import { Input } from 'antd';
import moment from 'moment'
const { TextArea } = Input;

// #0a99b8

export default function PatientNotes({notes,addNote}){
  const [text,setText] = useState('')
  // is in reverse so it starts scrolled to bottom
  var notesRev = notes && notes.slice().reverse();
  return <Scroller>
    <div style={{display:'flex',justifyContent:'center'}}>
      <Button
        text="Add Another Note"
        type="third"
        style={{
          background:'#0a99b8',padding:'2px 6px',
          width:'auto',
          padding:'0px 32px'
        }}
        onClick={()=> {
          if(!text) return
          addNote({
            text, date:moment().format('llll')
          })
          setText('')
        }}
      />
    </div>
    <div style={{marginTop:4,padding:10}}>
      <label htmlFor="notes">Notes</label>
      <TextArea value={text} onChange={e=>setText(e.target.value)} 
        placeholder="Enter notes here"  
        style={{
          resize:'none',padding:'12px 16px',
          marginTop:10,minHeight:120,fontSize:16,
          boxShadow:'0 0 6px 0 rgba(0, 0, 0, 0.16)'
        }}
      />
    </div>
    {notesRev && notesRev.map((n,i)=>(
      <Note key={i}>
        <Text>{n.text}</Text>
        <Date>{n.date}</Date>
      </Note>
    ))}
    <div htmlFor="notes" style={{color:'#0a99b8',fontWeight:'bold',marginLeft:10,marginTop:10,fontSize:16}}>
      Patient Notes
    </div>
    <div style={{minHeight:8,width:1}} />
  </Scroller>
}

function usePrevious(value) {
  const ref = useRef()
  useEffect(() => {
    ref.current = value
  }, [value])
  return ref.current
}

const Scroller = styled.div`
  overflow:scroll;
  max-height:389px;
  display:flex;
  flex-direction:column-reverse;
`
const Note=styled.div`
  width:100%;
  padding:10px;
`
const Text = styled.div`
  margin-top:4px;
`
const Date = styled.div`
  color:#aaa;
  margin-top:4px;
`