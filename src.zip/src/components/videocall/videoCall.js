import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import { patientProcedure, patientDevices } from '../form/schema'
import styled from 'styled-components'
import { Button, Title, BigTitle, Detail, Shadow } from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { patients, chartData } from '../fakeData'
import Chart from "../charts/chart";
import PatientPanel, {BigPanel, SmallPanel, PanelHead} from '../patients/shared/patientPanel'
import TopRow from '../patients/shared/topRow'
import {periods} from '../fakeTreatmentData'
import Notes from './notes'
import Settings from './settings'
import PatientApp from './patientApp'

import {Wrap,WrapRow,BigWrap,PanelTitle,Flank,ButtonRow} from './shared/styled'

const VideoCall = (props) => {
  const patientID = parseInt(props.computedMatch.params.patientID)
  const [step, setStep] = useState(0)
  const [submitting, setSubmitting] = useState(null)
  const history = useHistory()

  const patient = patients.find(p=>p.id===patientID)
//   if(!patient) {
//     return <NotFound>Patient Not Found</NotFound>
//   }


  const tabButtons = [
    {
        type:'util',
        color:'sea',
        text:'Notes',
        func:()=>setStep(0)
    },
    {
        type:'util',
        color:'sea',
        text:'Settings',
        func:()=>setStep(1),
    },
    {
        type:'util',
        color:'sea',
        text:'Patient App',
        func:()=>setStep(2),
    },
]

  // console.log("PATIENT DATA", patient)

  return (<Wrap >

    <TopRow label="Lamarche, Robert" backLabel="Patient List" 
      backAction={()=> history.push(`/patients`)}
      hidePDF
    />

    <ButtonRow>
      <Shadow>
          {tabButtons.map((b,i)=>{
              return <Button
              type={b.type}
              text={b.text} key={i}
              invert={step!==i}
              dead={b.dead}
              color={b.color}
              style={{margin:0,width:171}}
              onClick={()=>b.func()}
              />
          })}
        </Shadow>
    </ButtonRow>

    <BigWrap>
        {step===0?
        <Notes/>
        :step===1?
        <Settings />
        :
        <PatientApp/>}
    </BigWrap>

  </Wrap>);
}

export default VideoCall