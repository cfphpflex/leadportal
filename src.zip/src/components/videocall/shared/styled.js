import styled from 'styled-components'

export const Wrap = styled.div`
    display:flex;
    flex:1;
    position:relative;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    align-content:center; 
`
export const WrapRow=styled.div`
  display:flex;
  justify-content:space-between;
`

export const BigWrap=styled.div`
  display:flex;
  flex-direction:column;
  align-items:center;
  width:1640px;
`
export const PanelTitle =styled.div`
font-size: 22px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.5;
  letter-spacing: normal;
  text-align: left;
  color: #0899b7;
  width: 333px;
  margin-bottom:15px;
`

export const Flank =styled.div`
display:flex;
flex-direction:column;
width: 333px;
height: 682px;
border-radius: 10px;
box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.15);
background-color: #ffffff;
padding:20px;
`

export const VidWrap =styled.div`
width: 908px;
height: 682px;
border-radius: 10px;
background-image: url('/static/patient.png');
background-position: center; /* Center the image */
background-repeat: no-repeat; /* Do not repeat the image */
background-size: cover; /* Resize the background image to cover the entire container */
`

export const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:30px;
`

export const Shadow = styled.div`
border-radius: 10px;
box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.15);
`
