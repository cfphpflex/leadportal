import React, { useState, useEffect, useCallback, useContext } from 'react'
import { patientProcedure, patientDevices } from '../form/schema'
import styled from 'styled-components'
import { Button, TextArea, BigTitle, Detail, Shadow } from '../ui/romUI'
import { useHistory } from "react-router-dom";
import TopRow from '../patients/shared/topRow'
import {periods} from '../fakeTreatmentData'
import moment from 'moment'

import {WrapRow,BigWrap,PanelTitle,Flank,VidWrap,ButtonRow} from './shared/styled'

const oldnotes = [
    {
        value:"hi hello i'm here wagging my tail because you have a treat",
        date:moment().format('MM/DD/YYYY hh:mm')
    },
    {
        value:"hi hello i'm here wagging my tail because you have a treat",
        date:moment().format('MM/DD/YYYY hh:mm')
    },
    {
        value:"hi hello i'm here wagging my tail because you have a treat",
        date:moment().format('MM/DD/YYYY hh:mm')
    },
    {
        value:"hi hello i'm here wagging my tail because you have a treat",
        date:moment().format('MM/DD/YYYY hh:mm')
    }
]

const pData = [
    { name: 'dob', label: 'DOB', value:'02/23/1957'},
    { name: 'age', label: 'Age' ,value:'71'},
    { name: 'id', label: 'Patient ID',value:'124523' },
    { name: 'procedure', label: 'Procedure',value:'Knee Replacement' },
    { name: 'daysSince', label: 'Days since surgery', value:'28'},
    { name: 'phone', label: 'Phone', value:'(509) 985-3256'},
    { name: 'email', label: 'Email Address',value:'robert@robert.com' }
  ]

const Notes = (props) => {
    const [step, setStep] = useState(0)
    const [submitting, setSubmitting] = useState(null)
    const [note, setNote] = useState('')
    const history = useHistory()

    const [archivedNotes, setArchivedNotes] = useState(oldnotes)


    const tabButtons = [
        {
            type:'util',
            color:'sea',
            text:'Current',
            func:()=>setStep(0)
        },
        {
            type:'util',
            color:'sea',
            text:'Archived',
            func:()=>setStep(1),
        },
    ]

    async function submitNote(e){
        console.log('e',e)

        setNote('')
    }
    

  return (<div style={{width:'100%'}}>
                <WrapRow>
                    <PanelTitle>Current Patient</PanelTitle>
                    <PanelTitle>Patient Notes</PanelTitle>
                </WrapRow>

                <WrapRow>
                    <Flank>
                        <PatientName>
                            Lamarche, Robert
                        </PatientName>
                        
                        <div style={{padding:15,paddingTop:24}}>
                        {pData.map((d, i) => {
                            return <Detail key={i} label={d.label.toUpperCase()} style={{ width: 300,marginBottom:20 }} name={d.value} />
                            })}
                        </div>
                    </Flank>

                    <VidWrap>
                    </VidWrap>

                    <Flank>

                    <ButtonRow style={{marginBottom:20}}>
                    <Shadow>
                        {tabButtons.map((b,i)=>{
                            return <Button
                            type={b.type}
                            text={b.text} key={i}
                            invert={step!==i}
                            dead={b.dead}
                            color={b.color}
                            style={{margin:0,width:146}}
                            onClick={()=>b.func()}
                            />
                        })}
                        </Shadow>
                    </ButtonRow>

                {step===0?
                    <div style={{position:'relative'}}>
                        <TextArea 
                        label={'notes'}
                        value={note}
                        onChange={(e)=>setNote(e.target.value)}
                        onEnter={(e)=>console.log('e',e.target.value)}
                        style={{height:570,width:294,padding:20,paddingTop:16,resize: 'none'}} />

                        {/* <div style={{position:'absolute',bottom:0,left:0,
                        width:'100%',display:'flex',justifyContent:'center'}}>
                            <Button
                            style={{marginBottom:34,width:285}}
                            onClick={(e)=>submitNote(e)}
                            color={'secondary'}
                            text={'Submit'}
                            />
                        </div> */}
                    </div>
                    : 
                    <>
                    {archivedNotes&&archivedNotes.map((o,i)=>{
                    return <Archived key={i}>
                        <ArchText>{o.value}</ArchText>
                        <ArchDate>{o.date}</ArchDate>
                    </Archived>
                    })
                    }
                    </>
                }
                    </Flank>
                </WrapRow>
            </div>
);
}

export default Notes




const ArchText =styled.div`
    font-size: 16px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.19;
  letter-spacing: normal;
  text-align: left;
  color: #666666;
  margin-bottom:10px;
`

const ArchDate =styled.div`
    font-size: 16px;
font-weight: 500;
font-stretch: normal;
font-style: normal;
line-height: 1.19;
letter-spacing: normal;
text-align: left;
color: #adadad;
`


const Archived =styled.div`
    font-size: 16px;
  font-weight: 500;
  margin-bottom:20px;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.19;
  letter-spacing: normal;
  text-align: left;
  color: #666666;
`


const PatientName =styled.div`
    display:flex;
    align-items:center;
    padding:15px;
    width: 100%;
    height: 80px;
    border-radius: 10px;
    box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
    background-color: #f6fbfc;

    font-size: 22px;
    font-weight: 600;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.5;
    letter-spacing: normal;
    text-align: left;
    color: #055e6c;
`

