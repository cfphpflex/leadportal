import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import { patientProcedure, patientDevices } from '../form/schema'
import styled from 'styled-components'
import { Button, TextArea, BigTitle, Detail } from '../ui/romUI'
import { useHistory } from "react-router-dom";
import TopRow from '../patients/shared/topRow'
import {periods} from '../fakeTreatmentData'
import moment from 'moment'
import {WrapRow,BigWrap,PanelTitle,Flank,VidWrap,ButtonRow} from './shared/styled'


const PatientApp = (props) => {
    const [step, setStep] = useState(0)
    const [submitting, setSubmitting] = useState(null)
    const history = useHistory()

  return (<div style={{width:1550}}>
                <WrapRow>
                    <PanelTitle/>
                    <PanelTitle style={{width:1090}}>Patient App View</PanelTitle>
                </WrapRow>

                <WrapRow>

                    <div style={{display:'flex',flexDirection:'column',justifyContent:'space-between'}}>

                        <VidWrap style={{width: 427,height: 326}}>
                        </VidWrap>

                        <VidWrap style={{width: 427,height: 326}}>
                        </VidWrap>

                    </div>

                    <Flank style={{width:1090, background:'#222'}}>

                    </Flank>

                </WrapRow>
            </div>
);
}

export default PatientApp


const ArchText =styled.div`
    font-size: 16px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.19;
  letter-spacing: normal;
  text-align: left;
  color: #666666;
  margin-bottom:10px;
`

const ArchDate =styled.div`
    font-size: 16px;
font-weight: 500;
font-stretch: normal;
font-style: normal;
line-height: 1.19;
letter-spacing: normal;
text-align: left;
color: #adadad;
`



