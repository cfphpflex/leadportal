import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import { patientProcedure, patientDevices } from '../form/schema'
import styled from 'styled-components'
import { Button, TextArea, BigTitle, Detail } from '../ui/romUI'
import { useHistory } from "react-router-dom";
import TopRow from '../patients/shared/topRow'
import {periods,templates} from '../fakeTreatmentData'
import moment from 'moment'
import {WrapRow,BigWrap,PanelTitle,Flank,VidWrap,ButtonRow} from './shared/styled'
import CompoundSlider from '../ui/compoundSlider'
import { SliderRail, Track, Handle, Tick } from "../ui/compoundSlider/slider"


const Settings = (props) => {
    const [step, setStep] = useState(0)
    const [submitting, setSubmitting] = useState(null)
    const history = useHistory()
    const [sliderRefs, setSliderRefs] = useState({})
    const [sliderValues, setSliderValues] = useState({
        pedalRadius:[34],
        resistance:[13],
        rpm:[34,45],
        pedalRadius:[34],
        pressureLimit:[12]
    })

    const sliders = [
        {
            label:'Pedal Radius Adjustment',
            name:'pedalRadius',
            min:0,
            max:50,
            single:true,
        },
        {
            label:'Resistance',
            name:'resistance',
            min:0,
            max:50,
            single:true,
        },
        {
            label:'RPM',
            name:'rpm',
            min:0,
            max:50,
        },
        {
            label:'Pressure Limit',
            name:'pressureLimit',
            sub:"*For patient's with approximate weight of 250lbs*",
            single:true,
            min:0,
            max:50,
        },
    ]


    async function submitChanges(){
        setSliderRefs({})
    }

  return (<div style={{width:1440}}>
                <WrapRow>
                    <PanelTitle/>
                    <PanelTitle style={{width:501}}>PortableConnect Settings</PanelTitle>
                </WrapRow>

                <WrapRow>
                    <VidWrap style={{width:908}}>
                    </VidWrap>

                    <Flank style={{width:501,alignItems:'center',justifyContent:'space-between'}}>

                    <div>
                        {sliders.map((s,i)=>{
                            return <div key={i} style={{marginBottom:10,position:'relative'}}>

                            {sliderRefs[s.name]&&
                                <Ghost>
                                    <CompoundSlider 
                                    label={s.label}
                                    subtitle={s.sub}
                                    hideTrack
                                    value={sliderRefs[s.name]}
                                    min={s.min} max={s.max} single={s.single} />
                                </Ghost>
                            }

                            <CompoundSlider  label={s.label}
                            subtitle={s.sub}
                            onChange={(e)=>{
                                console.log('e',e)
                                setSliderValues({...sliderValues, [s.name]:e})
                                if (!sliderRefs[s.name]) setSliderRefs({...sliderRefs, [s.name]:sliderValues[s.name]})
                            }}
                            value={sliderValues[s.name]}
                            min={s.min} max={s.max} single={s.single} />
                            </div>
                        })}
                    </div>

                        <Button
                        text={'Confirm Changes'} 
                        color={'secondary'}
                        style={{margin:0,width: 225}}
                        onClick={()=>submitChanges()}
                        />
                    </Flank>
                </WrapRow>
            </div>
);
}

export default Settings


const ArchText =styled.div`
    font-size: 16px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.19;
  letter-spacing: normal;
  text-align: left;
  color: #666666;
  margin-bottom:10px;
`

const Ghost =styled.div`
    position:absolute;
    left:0;
    top:0;
    z-index:1;
    opacity:0.5;
    pointer-events:none;
    user-select:none;
`



