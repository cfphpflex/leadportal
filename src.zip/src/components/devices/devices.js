import React, { useState, useEffect, useCallback } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle,Input, Image,SubTitle,Shadow,Select} from '../ui/romUI'
import { Redirect } from "react-router-dom";
import DeviceBar from './deviceBar'
import ItemList from '../lists/itemList'
import { patientDevicesHeaders, devicesHeaders } from '../listHeaders'
import { devices, patients } from '../fakeData'

const Devices = (props) => {
    const [mode, setMode] = useState('With Patient')

    const deviceTabs = [
        {
            type:'util',
            color:'sea',
            text:'With Patient',
        },
        {
            type:'util',
            color:'sea',
            text:'Inventory',
        }
    ]

    const dropdowns = [
        {
            label:'Physical Therapists',
            name:'pts',
            type:'select',
            options:[
                {label:'Other',name:'other'}]
        },
        {
            label:'Surgeons',
            name:'surgeons',
            type:'select',
            options:[
                {label:'Other',name:'other'}]
        }
    ]

    const isWithPatient = mode==='With Patient'

    return (<Wrap>
        <DeviceBar />
        <ButtonRow>
            <Shadow>
                    {deviceTabs.map((b,i)=>{
                        return <Button
                        type={b.type}
                        text={b.text} key={i}
                        invert={mode!==b.text}
                        color={b.color}
                        style={{margin:0,width:171}}
                        onClick={()=>setMode(b.text)}
                        />
                    })}
                </Shadow>
            </ButtonRow>
            
        <div style={{width:'100%',display:'flex',justifyContent:'flex-start'}}>
                <SelectRow>
                    <div style={{display:'flex',justifyContent:'center',paddingTop:20,fontSize:16}}>
                        Filters:
                    </div>
                    {dropdowns.map((d,i)=>{
                        return <Select
                            style={{width:260}}
                            key={i}
                            hideLabels
                            {...d}
                            onBlur={(e)=>console.log('blur',e)}
                            onChange={(e)=>console.log('change',e)}
                        />
                    })}
                </SelectRow>
        </div>
        
        <div style={{display:'flex',width:'100%',position:'relative'}}>
        {isWithPatient?<ItemList headers={patientDevicesHeaders} 
            items={patients}/>
        :  <ItemList headers={devicesHeaders} 
            items={devices}/>
        }
        </div>
        </Wrap>
);
}

export default Devices

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    ${'' /* align-content:center;  */}
    ${'' /* align-items:center;  */}
`
const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:15px;
    margin-top:25px;
`

const SelectRow = styled.div`
    display:flex;
    justify-content:space-between;
    align-content:center; 
    width:605px;
    margin-left:35px;
`
