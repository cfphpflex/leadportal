import React, { useState, useEffect, useCallback } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle,Input, Image,SubTitle} from '../ui/romUI'
import { Redirect } from "react-router-dom";
import Select from '../form/fields/select'

const deviceList = [
    {
        name:'PortableConnect',
        image:'static/portableconnect.png',
        patients:'3',
        stock:'30',
        imgStyle:{
            width:182,
            height:97
        }
    },
    {
        name:'AccuAngle',
        image:'static/accuangle.png',
        patients:'3',
        stock:'30',
        imgStyle:{
            width:198,
            height:105
        }
    },
    {
        name:'AccuStep',
        image:'static/accustep.png',
        patients:'3',
        stock:'30',
        imgStyle:{
            width:91,
            height:52
        }
    },
]

const DeviceBar = (props) => {

    return (<div style={{display:'flex',justifyContent:'space-between'}}>
     {deviceList.map((d,i)=>{
         return <DeviceBox key={i}>
         <DTitle>{d.name}</DTitle>
         <Image style={d.imgStyle} source={d.image}/>

        <div style={{display:'flex',width:'100%',justifyContent:'space-between'}}>
            <DeetBox>
                <DN>{d.patients}</DN>
                <DL>With Patients</DL>
            </DeetBox>
            <DeetBox>
                <DN>{d.stock}</DN>
                <DL>In Stock</DL>
            </DeetBox>
         </div>

</DeviceBox>
         })}
    </div>
       
    )
}


export default DeviceBar


const DeviceBox = styled.div`
    display:flex;
    padding:30px;
    margin:15px;
    flex-direction:column;
    align-items:center;
    justify-content:space-between;
    align-content:center; 
    width: 556px;
    height: 357px;
    border-radius: 10px;
    box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.15);
    background-color: #ffffff;
`

const DTitle = styled.div`
    font-size: 28px;
    font-weight: 600;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.18;
    letter-spacing: normal;
    text-align: center;
    color: #0899b7; 
`
const DeetBox = styled.div`
  width: 233px;
  height: 106px;
  display:flex;
  padding:10px;
  padding-top:25px;
  flex-direction:column;
  align-items:center;
  justify-content:space-between;
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background-color: #f6fbfc;
`

const DN = styled.div`
    font-size: 48px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 0.69;
  letter-spacing: normal;
  text-align: center;
  color: #00b2ce;
  `
  const DL = styled.div`
  font-size: 18px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.83;
  letter-spacing: normal;
  text-align: center;
  color: #666666;
  `