import React, { useState, useEffect, useCallback } from './node_modules/react'
import Form from '../form/form'
import { patientProcedure, patientDevices } from '../form/schema'
import styled from './node_modules/styled-components'
import { Button, Title, BigTitle, Detail, Select } from '../ui/romUI'
import { useHistory } from "./node_modules/react-router-dom";
import { adminChartData, adminStatData } from '../fakeData'
import Chart from "../charts/chart";
import PatientPanel, {BigPanel, SmallPanel, PanelHead} from '../patients/shared/patientPanel'
import TopRow from '../patients/shared/topRow'
import {periods} from '../fakeTreatmentData'

const AdminDashboard = (props) => {
  const patientID = parseInt(props.computedMatch.params.patientID)

  const [submitting, setSubmitting] = useState(null)
  const history = useHistory()

  const prData = [
    { name: 'procedure', label: 'Procedure' },
    { name: 'procedureDate', label: 'Procedure Date' },
    { name: 'lastSession', label: 'Last Session' },
    { name: 'postOpDay', label: 'Days Since Surgery' },
  ]

  const cData = [
    { name: 'romExtF', label: 'Extension' },
    { name: 'flexion', label: 'Flexion' },
    { name: 'pain', label: 'Pain Level' },
    { name: 'sessionCompTot', label: 'Sessions Comp/Tot' },
  ]

  // protocol > session > period
  const periodColors={
    assisted:'#01b2cf',
    active:'#0a99b8',
    resistance:'#065d6b',
  }

  const charts = [
    {title:'Total Practices',type:'line',yLabel:'AMOUNT',unit:'',xLabel:'DAYS'},
    {title:'Total Clinicians',type:'bar',yLabel:'AMOUNT',unit:'',xLabel:'DAYS'},
    {title:'Total DMEs',type:'bar',yLabel:'AMOUNT',xLabel:'DAYS'},
    {title:'Total Physical Therapists',type:'line',yLabel:'AMOUNT',xLabel:'DAYS'},
    {title:'Total Patients',type:'line',yLabel:'AMOUNT.',xLabel:'DAYS'},
    {title:'Total PortableConnects',type:'bar',yLabel:'AMOUNT',xLabel:'DAYS'},
  ]

  const dropdowns = [
    {
        label:'Physical Therapists',
        name:'pts',
        type:'select',
        options:[
            {label:'Current Week',name:'week'},
            {label:'Last Week',name:'lastweek'},
            {label:'Last Month',name:'lastmonth'},
            {label:'Last Year',name:'lastyear'}]
    },
]

const statColors = ['#00b2ce','#0899b7','#087a91','#055e6c']

  return (<Wrap>
            <Title title={'Admin Dashboard'}/>

                <SelectRow>
                    <div style={{display:'flex',justifyContent:'center',paddingTop:20,fontSize:16,marginRight:10}}>
                        Filters:
                    </div>
                    {dropdowns.map((d,i)=>{
                        return <div key={i}><Select
                            style={{width:260,marginRight:10}}
                            hideLabels
                            {...d}
                            onBlur={(e)=>console.log('blur',e)}
                            onChange={(e)=>console.log('change',e)}
                        /></div>
                    })}
                </SelectRow>

                

                <WrapRow style={{marginBottom:30}}>
                {adminStatData&&adminStatData.map((d,i)=>{
                  return <StatPanel key={i}>
                  <Stat color={statColors[i]}>{d.value}</Stat>
                  <StatTitle>{d.label}</StatTitle>
                  </StatPanel>
                })}
                 
                </WrapRow>
    
                <WrapRow>
                  {charts && charts.map((c,i)=>{
                    return <ChartPanel key={i}>
                      <PanelHead>{c.title}</PanelHead>
                      <Chart data={adminChartData} type={c.type}
                        yLabel={c.yLabel} xLabel={c.xLabel} unit={c.unit} 
                      />
                    </ChartPanel>
                  })}
                </WrapRow>

  </Wrap>);
}

export default AdminDashboard

const Wrap = styled.div`
    display:flex;
    flex:1;
    min-width:1300px;
    max-width:3000px;
    position:relative;
    flex-direction:column;
    ${'' /* justify-content:center; */}
    align-content:center; 
`
const WrapRow=styled.div`
  display:flex;
  justify-content:space-between;
  flex-wrap:wrap;
  width:1348px;
`
const Row=styled.div`
  display:flex;
  justify-content:space-between;
`

const ChartPanel = styled.div`
  width: 659px;
  height: 355px;
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background-color: #ffffff;
  margin-bottom:30px;
  padding: 20px 40px;
`
const StatPanel = styled.div`
  display:flex;
  align-items:center;
  justify-content:flex-start;
  flex-direction:column;
  padding:23px;
  padding-top:65px;
  width: 305px;
  height: 209px;
  border-radius: 10px;
  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.16);
  background-color: #ffffff;
`

const Stat = styled.div`
  font-size: 70px;
  font-weight: 600;
  font-stretch: normal;
  font-style: normal;
  line-height: 0.46;
  letter-spacing: normal;
  color: #087a91;
  margin-bottom:30px;
  color:${p=>p.color?p.color:null};
`

const StatTitle = styled.div`
font-size: 17px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.29;
  letter-spacing: normal;
  color: #666666;
  max-width:244px;
  text-align:center;
`




const SelectRow = styled.div`
    display:flex;
    justify-content:flex-start;
    align-content:center; 
    width:880px;
`