import moment from 'moment'

export const periods = [
    {id:1,type:'assisted', minutes:5, direction:'Forward'},
    {id:2,type:'assisted', minutes:5, direction:'Forward'},
    {id:3,type:'active', minutes:5, direction:'Backwards'},
    {id:4,type:'active', minutes:5, direction:'Forward'},
    {id:5,type:'resistance', minutes:5, direction:'Backwards'},
]
export const periods2 = [
    {id:11,type:'assisted', minutes:5, direction:'Forward'},
    {id:12,type:'active', minutes:5, direction:'Backwards'},
    {id:13,type:'active', minutes:5, direction:'Backwards'},
    {id:14,type:'active', minutes:5, direction:'Forward'},
    {id:15,type:'resistance', minutes:5, direction:'Backwards'},
    {id:16,type:'active', minutes:5, direction:'Backwards'},
    {id:17,type:'active', minutes:5, direction:'Forward'},
    {id:18,type:'resistance', minutes:5, direction:'Backwards'},
]
export const periods3 = [
    {id:21,type:'assisted', minutes:5, direction:'Forward'},
    {id:22,type:'assisted', minutes:5, direction:'Forward'},
    {id:23,type:'active', minutes:5, direction:'Backwards'},
    {id:24,type:'active', minutes:5, direction:'Forward'},
    {id:25,type:'resistance', minutes:5, direction:'Backwards'},
    {id:26,type:'passive', minutes:5, direction:'Forward'},
]

export const protocols = [
    {id:1,label:'Daily',purpose:'Strengthening',periods:periods3,sessionNum:3,daysNum:5,leg:'right'},
    {id:2,label:'Weekly',purpose:'Strengthening',periods:periods2,sessionNum:4,daysNum:5,leg:'right'},
    {id:3,label:'Acute',purpose:'Strengthening',periods,sessionNum:5,daysNum:5,leg:'right'},
    {id:4,label:'Unnamed Protocol',purpose:'Strengthening',periods,sessionNum:3,daysNum:5,leg:'right'},

    {id:5,label:'Another protocol',purpose:'Something',periods,sessionNum:3,daysNum:5,leg:'left'},
    {id:6,label:'A cool protocol',purpose:'Something',periods,sessionNum:3,daysNum:5,leg:'left'},
    {id:7,label:'Something else',purpose:'Something',periods,sessionNum:3,daysNum:5,leg:'left'},

    {id:8,label:'A protocol title',purpose:'Healing',periods,sessionNum:3,daysNum:5,leg:'bilateral'},
    {id:9,label:'An awesome protocol',purpose:'Getting Better',periods,sessionNum:3,daysNum:5,leg:'bilateral'},
    {id:10,label:'Pump it up',purpose:'Up and Running',periods,sessionNum:3,daysNum:5,leg:'bilateral'},
]

export const emptyProtocol = {
    id:0,label:'Unnamed Protocol',periods:[],sessionNum:3,daysNum:5,leg:'right'
}

export const templates = [
    {id:1,label:'Strengthening Template',protocols:protocols.filter(p=>p.id<5)},
    {id:2,label:'Test Template 1',protocols:protocols.filter(p=>p.id>=5&&p.id<8)},
    {id:3,label:'Test Template 2',protocols:protocols.filter(p=>p.id>=8&&p.id<11)},
]

export const patientNotes = [
    {text:'A quick brown fox jumps over the lazy dog', date:moment().format('llll')},
    {text:'Loreum ipsum is some kind of latin text and i have no idea what it actually means', date:moment().format('llll')},
    {text:'Another note that is kindof long so we can test that the text wraps nicely around and does not make this part of the app look like crap or anything like that that blah blah blah... Another note that is kindof long so we can test that the text wraps nicely around and does not make this part of the app look like crap or anything like that that blah blah blah', date:moment().format('llll')},
    {text:'Another note that is kindof long so we can test that the text wraps nicely around and does not make this part of the app look like crap or anything like that that blah blah blah... Another note that is kindof long so we can test that the text wraps nicely around and does not make this part of the app look like crap or anything like that that blah blah blah', date:moment().format('llll')},
    {text:'Another note that is kindof long so we can test that the text wraps nicely around and does not make this part of the app look like crap or anything like that that blah blah blah... Another note that is kindof long so we can test that the text wraps nicely around and does not make this part of the app look like crap or anything like that that blah blah blah', date:moment().format('llll')},
]