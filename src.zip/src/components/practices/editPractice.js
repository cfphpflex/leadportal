import React, { useState, useEffect, useCallback, useContext } from 'react'
import Form from '../form/form'
import {practice} from '../form/schema'
import styled from 'styled-components'
import { Button, Title, BigTitle} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import { get,patch } from '../../provider/api'   // UPDATE Practice only needs GET & PATCH methods
import { useRom } from '../../provider/rom'   // UPDATE Practice only needs GET & PATCH methods
import EE from '../utils/events'

const CreateNewPractice = () => {
    const rom = useRom()
    const {ui} = rom

    const [submitting, setSubmitting] = useState(null)
    const [renderForm, setRenderForm] = useState(true)
    const [initialValues, setInitialValues] = useState({})
    
    const {practiceTypes} = ui
    const history = useHistory()
    const formButtons = [
        {type:'submit','text':'Save Changes',color:'submit', style:{width:375}},
    ]

    useEffect(()=>{

        EE.on('fill-address',(e)=>{
            console.log('fill address',e)
            let updates = {...e}
            setInitialValues(updates)
            refreshForm()
        })

        EE.on('fill-form',(e)=>{
            console.log('fill form',e)
            let updates = {...e}
            setInitialValues(updates)
            refreshForm()
        })
    },[])

    function refreshForm(){
        setRenderForm(false)
        setTimeout(()=>{
            setRenderForm(true)
        },20)
    }

    async function edit(v){
        const oF = v.office_phone
        let phoneFormatted = ''+oF['0']+oF['1']+oF['2']

        const data = {
            "npi": v.npi+'',
            "name": v.practiceName,
            "practice_type_id": v.practiceType.id,
            "address":
                {
                    "line_1": v.line_1||'',
                    "city": v.city||'',
                    "state": v.state||'',
                    "zip_code": v.zip_code||''
                },
            "phone_number":
                {
                    "phone_name": "Office Phone",
                    "phone_number": phoneFormatted?phoneFormatted:''
                }
        }

        try{
            setSubmitting(true)
            const res = await patch('practice/'+v.practiceType.id,data)
            history.push('/editPractice')
        } catch(e){
            setSubmitting(false)
            console.log('e',e)
        }
    }



    //2.  pull data into const practiceDataType for the dropdown


    const practiceType = practice.map(p=>{
        return {
            ...p,
            options:p.options&&p.options.map(o=>{
                return {...o}
            })
        }
    })



    const pConfig = practice.map(p=>{
        return {
            ...p,
            options:p.options&&p.options.map(o=>{
                return {...o}
            })
        }
    })

    if (practiceTypes&&practiceTypes.length) {
        pConfig[2].options = [...practiceTypes]
    }
    

    return (<Wrap>
            <Title title={'Edit Practice'} />
            {renderForm&&<Form
                config={pConfig}
                submitting={submitting}
                initialValues={initialValues}
                buttons={formButtons}
                inputWidth={386}
                formStyle={{flexWrap:'wrap',flexDirection:'row',justifyContent:'space-between',maxWidth:800}}
                onSubmit={(v)=>edit(v)}
            />}
    </Wrap>);
}

export default CreateNewPractice

const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    align-content:center; 
`
