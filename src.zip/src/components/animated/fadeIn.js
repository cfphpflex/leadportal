import React from 'react';
import styled from 'styled-components'

const sleep = ms=> new Promise(resolve => setTimeout(resolve, ms))

class FadeIn extends React.Component {
    state = {
      translation: 40,
      opacity: 0,
      shouldRender:false
    }
  
    doAnimation = (value) => {
      if (value === 1){
          this.setState({translation:0,opacity:1})
      } else {
        this.setState({translation:40,opacity:0})
      }
    }

    async componentDidMount(){
      const { isMounted } = this.props
      if (isMounted){
        this.setState({shouldRender:true})
        this.doAnimation(1)
      }
    }

    async componentDidUpdate(prevProps) {
      if (prevProps.isMounted && !this.props.isMounted) {
       this.doAnimation(0)
       await sleep(200)
       console.log('unmount')
       this.setState({ shouldRender: false })
      
      } else if (!prevProps.isMounted && this.props.isMounted) {
        this.setState({ shouldRender: true });
        await sleep(5)
        console.log('render true')
        this.doAnimation(1)
      }
    }
  
    render() {
      let { translation, opacity, shouldRender } = this.state;
      let { style, children } = this.props

      if (!shouldRender) return <div style={{position:'absolute',left:0,top:0}}/>
  
      return (
        <Fader style={{...style,transform:`translateY(${translation}px)`,opacity}}>
          {children}
        </Fader>
      );
    }
  }

export default FadeIn

const Fader = styled.div`
    transition:all 0.2s;
`