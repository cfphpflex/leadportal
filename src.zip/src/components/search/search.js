import React, { useState, useEffect, useCallback, useContext } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle,Input, SubTitle} from '../ui/romUI'
import { Redirect } from "react-router-dom";
import ItemList from '../lists/itemList'
import { patientsHeaders } from '../listHeaders'
import { patients } from '../fakeData'
import * as api from "../../provider/api";

const Search = (props) => {

    const [searchTerm, setSearchTerm] = useState('')


    function onChange(e){
        setSearchTerm(e)
    }
    const searchItems = new Object();
    useEffect(()=>{
        setTimeout(()=>{
            // wait for ui to fill with token
            getData()
        },500)
    },[])

    async function getData(){
        console.log('start getting data')
        let search = []

        const s = await api.post('search/query')
        if (s&&s.results) search = s.results
        console.log('before search data')
        console.log(search)
        console.log('done search data')

        search.forEach((n)=>{

            searchItems.name =['n.template_name']
            searchItems.days ='16'
            searchItems.description ='My cool template'
            searchItems.isDefault = true

           /* searchItems['name'] = n['template_name']
            searchItems['days'] = '16'
            searchItems['description'] = 'My cool template'
            searchItems['isDefault'] = true*/

        })

        console.log('before search data')
        console.log(searchItems)
        console.log('done search data')
       // setUI({search})

    }

    const pops = ['Knee Replacement','Hip Replacement','Straightening Template',
    'Test Template 1','Staff','Clinician']

    const results = ['results']

    return (<Wrap>
            <Title title={'Search'}/>
            
            <Input 
                style={{width:750}}
                icon={'static/glass.png'}
                type={'text'}
                placeholder={'Search'}
                onChange={(e)=>onChange(e.target.value)}
            />

            {searchTerm==='oops'?
                <Box style={{marginTop:40}}>
                    <Image
                    source={'static/noresults.png'}
                    style={{marginBottom:32}}
                    />
                    <SubTitle title="No results were found"/>
                </Box>
                :
                searchTerm?
                <div style={{padding:50,paddingTop:20}}>
                    <ItemList 
                    items={patients}
                    headers={patientsHeaders} camera/>
                </div>
            
            :   <Box style={{marginTop:20}}>
                    <div style={{fontSize:20}}>Popular Searches</div>
                    <Pops>
                        {pops.map((p,i)=>{
                            return <Lnk key={i}>{p}</Lnk>
                        })}
                    </Pops>
                </Box>
            }
    </Wrap>);
}

export default Search

const Lnk = styled.div`
    padding:15px;
    cursor:pointer;
`
const Image = styled.div`
    background-image: ${p=>`url(${p.source})`};
    width:198px;
    height:200px;
    background-position: center; /* Center the image */
    background-repeat: no-repeat; /* Do not repeat the image */
    background-size: contain; /* Resize the background image to cover the entire container */
`


const Wrap = styled.div`
    display:flex;
    flex:1;
    flex-direction:column;
    justify-content:center;
    align-content:center; 
    align-items:center; 
`
const Box = styled.div`
    display:flex;
    flex-direction:column;
    justify-content:center;
    align-content:center; 
    align-items:center; 
    width:600px;
`

const Pops = styled.div`
    width:100%;
    margin-top:20px;
    column-count:2;
    font-size: 18px;
    font-weight: 500;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.22;
    letter-spacing: normal;
    text-align: center;
    color: #055e6c;
  `