import React, { useState, useEffect, useCallback, useContext } from 'react'
import styled from 'styled-components'
import { Button, Title, BigTitle} from '../ui/romUI'
import { useHistory } from "react-router-dom";
import {get, post} from '../../provider/api'
import {useRom} from '../../provider/rom'
import EE from '../utils/events'
import ItemList from '../lists/itemList'
import { treatmentTemplatesHeaders } from '../listHeaders'
import * as api from "../../provider/api";
import { fakeTreatmentTemplates } from '../fakeData'
//import axios from 'axios'

const TreatmentPlanTemplates = () => {
    const rom = useRom()
    const [submitting, setSubmitting] = useState(null)
    const history = useHistory()
    const {ui, setUI} = rom
   // const [templates] = useState({})


    const templatesItems = {}

    /* const templates = [
        {
            name:'Straightening Template',
            days:'16',
            description:'My cool template',
            isDefault:true
        },
        {
            name:'Another Cool Template',
            days:'6',
            description:'My cool template',
        },
        {
            name:'Test Template 5',
            days:'1',
            description:'Heres a test template',
        },
        {
            name:'Straightening Template 2',
            days:'16',
            description:'My cool template',
        },
    ]*/
    const buttons = [
        {
            color:'secondary',
            text:'Set as Default',
            func:(p)=>setAsDefault(p),
            style:{width:400}
        },
    ]

    function setAsDefault(p){

    }
    useEffect(()=>{
        setTimeout(()=>{
            // wait for ui to fill with token
            getData()
        },500)
    },[])
    async function getData(){
        console.log('start getting data')
        let templates = []

        const t = await api.post('patient_treatment_plan/query')
        if (t&&t.results) templates = t.results
        console.log('before temp data')
        console.log(templates)
        console.log('done temp data')
        const index = 1;


                   /*     templatesItems&&templatesItems.forEach((p)=>{
                            templatesItems.push({
                                label:p.name,
                                name:p.name,
                                id:p.id,
                                type:'boolean',
                            })
                        })
                */

        templates.forEach((n)=>{

          /*  templatesItems.push({
                name:n['template_name'],
                days:'16',
                description: 'My cool template',
                idDefault: true
            })*/

           // templatesItems[index+1]
            templatesItems['name'] = n['template_name']
            templatesItems['days'] = '16'
            templatesItems['description'] = 'My cool template'
            templatesItems['isDefault'] = true

        })

        console.log('before getting data')
        console.log(templatesItems)
        console.log('done getting data')
        setUI({templates})

    }


    return (<Wrap>
            <Title title={'Treatment Plan Templates'}/>
            <Button 
                color={'third'}
                text={'Add New Template'}
                onClick={()=>history.push('/treatmentPlan/new')}
                style={{position:'absolute',
                top:30,
                width:280,
                right:38}}
            />

            <div style={{display:'flex',flexDirection:'column',padding:50,paddingTop:20,width:'100%'}}>
            
                    <ItemList 
                   // items={templatesItems}
                    items={fakeTreatmentTemplates}
                    headers={treatmentTemplatesHeaders}
                    buttons={buttons} />
                </div>
    </Wrap>);
}

export default TreatmentPlanTemplates

const Wrap = styled.div`
    display:flex;
    flex:1;
    position:relative;
    flex-direction:column;
    width:100%;
    ${'' /* justify-content:center; */}
    align-content:center; 
`

const ButtonRow = styled.div`
    display:flex;
    justify-content:center;
    align-content:center; 
    margin-bottom:30px;
`

