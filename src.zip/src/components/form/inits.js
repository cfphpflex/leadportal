import * as Yup from 'yup';
import * as schema from './schema'

const stringTypes = ['text','password','address','search','npi','textarea','radio','dropdown','audio','video','color']

function validator(config){
    const shape = {}
    config.forEach((field)=>{
        if(typeof field === 'object') {
            shape[field.name] = field.validator
        }
    })
    return Yup.object().shape(shape)
}

function initialize(config) {
    const values = {}
    config.forEach((field)=>{
        if(typeof field === 'object') {
            if(stringTypes.includes(field.type)){
                values[field.name] = ''
            } else if(field.type==='time'||field.type==='datetime'){
                //values[field.name] = Math.round(Date.now().valueOf())
            } else if(field.type==='boolean'){
                values[field.name] = false
            } else if(field.type==='number'){
                values[field.name] = 0
            } else if(field.type==='checkbox'){
                values[field.name] = []
            } else if(field.type==='phone'||field.type==='date'){
                values[field.name] = {'0':'','1':'','2':''}
            } else if(field.type==='image'){
                values[field.name] = {}
            } else {
                values[field.name] = null
            }
            // if(field.type==='select'){
            //     const firstOption = field.options[0]
            //     values[field.name] = firstOption
                // const type = typeof firstOption.name
                // if(type==='string'){
                //     values[field.name] = ''
                // } else {
                //     values[field.name] = null
                // }
            // }
        }
    })
    return values
}

// const placeHolderStrings={
//     enter:{
//         en:'Enter',
//         es:'Ingrese'
//     },
//     select:{
//         en:'Select',
//         es:'Seleccione'
//     }
// }
// function makePlaceholder(config, lang){
//     let key = 'enter'
//     if(config.type==='select') key='select'
//     const s = placeHolderStrings[key][lang]
//     return `${s} ${config.label[lang]}`
// }
// function makeConfig(entity, l){
//     const config = schema[entity]
//     if (!(config && config.length)) return null
//     const lang = l || 'en'
//     return config.map(e=>{
//         if (typeof e!=='object') return e
//         const obj = {
//             ...e, 
//             label:e.label[lang] || (typeof e.label==='string'?e.label:''),
//             placeholder: makePlaceholder(e, lang)
//         }
//         if(obj.type==='select'){
//             obj.options = obj.options().map(o=>{
//                 return {name:o.name, label:o[lang] || o.name}
//             })
//         }
//         return obj
//     })
// }

export {
    // makeConfig,
    validator,
    initialize,
}