import { icd10 } from './icd10'
import * as Yup from 'yup'
import {post} from "../../provider/api";
const rq = 'Required'



export const login = [
    {
        label:'Email Address',
        name:'email',
        type:'text',
        icon:'user',
    },
    {
        label:'Password',
        name:'password',
        type:'password',
        icon:'lock',
    }
]

export const forgotPassword = [
    {
        label:'Email Address',
        name:'email',
        type:'text',
        validator: Yup.string().email('Not a valid email').required(rq),
        icon:'user',
    },
]



// do axios call
// here


// 1.  make this Axios work
async function practice_type(v){
    const practiceTypeRes = await post('practice_type/query')
}


//1. a. set the data  to use //
export const practiceType = [
                        {
                            object: [
                                {label: 'Standard', name: 'standard', id: 0},
                                {label: 'Special', name: 'special', id: 1},
                                {label: 'Other', name: 'other', id: 2}]
                        }
    ]

export const practice = [
    {
        label:'NPI*',
        name:'npi',
        type:'npi',
        validator: Yup.string().length(10)
            .required(rq)
    },
    {
        label:'Practice Name*',
        name:'practiceName',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'Practice Type*',
        name:'practiceType',
        type:'select',
        options:[
            {label:'Standard',name:'standard', id:0},
            {label:'Special',name:'special',id:1},
            {label:'Other',name:'other',id:2}],
        validator: Yup.object().required(rq),
    },
    {
        label:'Address*',
        name:'line_1',
        type:'address',
        validator: Yup.string().required(rq),
    },
    {
        label:'City*',
        name:'city',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'State*',
        name:'state',
        type:'text',
        validator: Yup.string().length(2).required(rq),
    },
    {
        label:'Zip Code*',
        name:'zip_code',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'Office Phone*',
        name:'office_phone',
        type:'phone',
        validator: Yup.object().shape({
            '0': Yup.string().length(3).required(rq),
            '1': Yup.string().length(3).required(rq),
            '2': Yup.string().length(4).required(rq),
          }),
    },
]

export const npi = [
    {
        label:'First Name',
        name:'firstName',
        type:'text',
    },
    {
        label:'Last Name',
        name:'lastName',
        type:'text',
    },
    {
        label:'Organization',
        name:'organization',
        type:'text',
    },
    {
        label:'NPI',
        name:'npi',
        type:'text',
    },   
]

export const teamMember = [
    {
        label:'NPI*',
        name:'npi',
        type:'npi',
        hideField:['org'],
        validator: Yup.string().length(10)
            .required(rq)
    },
    {
        label:'Role*',
        name:'role',
        type:'select',
        options:[
            {label:'Doc',name:'doc',id:0},
            {label:'Surgeon',name:'surgeon',id:40},
            {label:'Physical Therapist',name:'physicaltherapist',id:41},
            {label:'Other',name:'other',id:2}],
        validator: Yup.object().required(rq),
    },
    {
        label:'Surgeon',
        name:'surgeon',
        type:'select',
        options:[
            {label:'Placeholder',name:'doc',id:0},
            {label:'Placeholder',name:'surgeon',id:40},
            {label:'Placeholder Therapist',name:'physicaltherapist',id:41},
            {label:'Placeholder',name:'other',id:2}],
    },
    {
        label:'Prefix',
        name:'prefix',
        type:'text',
    },
    {
        label:'First Name*',
        name:'first_name',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'Last Name*',
        name:'last_name',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'Email*',
        name:'email',
        type:'text',
        validator: Yup.string().email('Not a valid email').required(rq),
    },
    {
        label:'Password*',
        name:'password',
        type:'password',
        validator: Yup.string().required(rq)
        .matches(
            /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
            'Upper, lower, number, and specials'
          )
    },
    {
        label:'Confirm password*',
        name:'confirmPassword',
        type:'password',
        validator: Yup.string()
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
            .required(rq),
    },
    {
        label:'Office Phone*',
        name:'office_phone',
        type:'phone',
        validator: Yup.object().shape({
            '0': Yup.string().length(3).required(rq),
            '1': Yup.string().length(3).required(rq),
            '2': Yup.string().length(4).required(rq),
          }),
    },
    {
        label:'Mobile Phone',
        name:'mobile_phone',
        type:'phone',
    },
    {
        label:'space',
        name:'space',
        type:'space',
    }
]

export const permissions = [
    {
        label:'Add Patient',
        name:'addPatient',
        type:'boolean',
    },
    {
        label:'Add Staff',
        name:'addStaff',
        type:'boolean',
    },
    {
        label:'Add Surgeon',
        name:'addSurgeon',
        type:'boolean',
    },
    {
        label:'Add Treatment Plan',
        name:'addTreatmentPlan',
        type:'boolean',
    },
    {
        label:'Edit Patient',
        name:'editPatient',
        type:'boolean',
    },
    {
        label:'Edit Staff',
        name:'editStaff',
        type:'boolean',
    },
    {
        label:'Edit Surgeon',
        name:'editSurgeon',
        type:'boolean',
    },
    {
        label:'Edit Treatment Plan',
        name:'editTreatmentPlan',
        type:'boolean',
    },
    {
        label:'View Patient List',
        name:'viewPatientList',
        type:'boolean',
    },
    {
        label:'View Patient Personal Data',
        name:'viewPatientPersonalData',
        type:'boolean',
    },
    {
        label:'View Patient Medical Data',
        name:'viewPatientMedicalData',
        type:'boolean',
    },
    {
        label:'View Patient Dashboard',
        name:'viewPatientDashboard',
        type:'boolean',
    },
    {
        label:'View Staff',
        name:'viewStaff',
        type:'boolean',
    },
    {
        label:'View Surgeon',
        name:'viewSurgeon',
        type:'boolean',
    },
    {
        label:'View Treatment Plan',
        name:'viewTreatmentPlan',
        type:'boolean',
    },
]

export const notifications = [
    {
        label:'Excessive Pain, Swelling/Stiffness and/or Draining',
        name:'excessives',
        type:'boolean',
    },
    {
        label:'Missed Session',
        name:'missedSession',
        type:'boolean',
    },
    {
        label:'No Session In last 24 Hours',
        name:'noSessionInLast24Hours',
        type:'boolean',
    },
    {
        label:'Pain level 7+',
        name:'painLevel7',
        type:'boolean',
    },
    {
        label:'Session Started',
        name:'sessionStarted',
        type:'boolean',
    },
]

export const patient = [
    {
        label:'First Name*',
        name:'first_name',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'Last Name*',
        name:'last_name',
        type:'text',
        validator: Yup.string().required(rq),
    },
    {
        label:'Date of Birth*',
        name:'date_of_birth',
        type:'date',
        validator: Yup.object().shape({
            '0': Yup.string().length(2).required(rq),
            '1': Yup.string().length(2).required(rq),
            '2': Yup.string().length(4).required(rq),
          }),
    },
    {
        label:'Surgeon*',
        name:'surgeon',
        type:'npi',
        searchTarget:'surgeon',
        validator: Yup.string().required(rq),
        hideField:['org']
    },
    {
        label:'Physical Therapist',
        name:'pt',
        type:'npi',
        searchTarget:'LeadExchange',
        hideField:['org']
    },
    {
        label:'DME',
        name:'dme',
        type:'npi',
        searchTarget:'LeadExchange',
        hideField:['org']
    },
    {
        label:'Address',
        name:'address',
        type:'address',
        // validator: Yup.string().required(rq),
    },
    {
        label:'City',
        name:'city',
        type:'text',
        // validator: Yup.string().required(rq),
    },
    {
        label:'State',
        name:'state',
        type:'text',
        validator: Yup.string().length(2),
    },
    {
        label:'Zip Code',
        name:'zip_code',
        type:'text',
        // validator: Yup.string().required(rq),
    },
    {
        label:'Home Phone',
        name:'home_phone',
        type:'phone',
    },
    {
        label:'Mobile Phone',
        name:'mobile_phone',
        type:'phone',
    },
    {
        label:'Email',
        name:'email',
        type:'text',
        validator: Yup.string().email('Not a valid email'),
    },
    // {
    //     label:'space',
    //     name:'space',
    //     type:'space',
    // },
    // {
    //     label:'space',
    //     name:'space',
    //     type:'space',
    // }  
]

export const patientProcedure = [
    {
    label:'Procedure*',
    name:'procedure',
    type:'text',
    validator: Yup.string().required(rq),
  },
  {
    label:'Primary Diagnosis (ICD10)',
    name:'diagnosis',
    type:'select',
    options:icd10,
  },
  {
    label:'Procedure Leg*',
    name:'procedureLeg',
    type:'select',
    options:[
        {label:'Left',name:'left',id:'0'},
        {label:'Right',name:'right',id:'1'}],
    validator: Yup.object().required(rq),
  },
  {
    label:'Procedure Date',
    name:'proceduredate',
    type:'date',
  },
  {
    label:'Treatment Start Date',
    name:'treatmentStartDate',
    type:'date',
  },
  {
        label:'space',
        name:'space',
        type:'space',
    },
]

export const patientDevices = [
      {
        label:'PortableConnect Serial Number*',
        name:'portableConnect',
        type:'text',
        validator: Yup.string().required(rq),
      },
      {
        label:'AccuAngle Serial Number',
        name:'accuAngle',
        type:'text',
      },
      {
        label:'AccuStep Serial Number',
        name:'accuStep',
        type:'text',
      }
]


export const something = [{
    label:'Something',
    name:'storeName',
    type:'text',
    icon:'store',
    // validator: Yup.string().required(rq),
  },
  {
    label:'Address',
    name:'address',
    type:'address',
    icon:'location',
    // validator: Yup.object().shape({
    //     address: Yup.string().required(),
    //     point: Yup.object().required(),
    // }),
  }
]



