const icd10 = [
    {id:'A00-B99', name:'A00-B99: Certain infectious and parasitic diseases',label:'A00-B99: Certain infectious and parasitic diseases'},
    {id:'C00-D49', name:'C00-D49: Neoplasms',label:'C00-D49: Neoplasms'},
    {id:'D50-D89', name:'D50-D89: Diseases of the blood and blood-forming organs and certain disorders involving the immune mechanism',label:'D50-D89: Diseases of the blood and blood-forming organs and certain disorders involving the immune mechanism'},
    {id:'E00-E89', name:'E00-E89: Endocrine, nutritional and metabolic diseases',label:'E00-E89: Endocrine, nutritional and metabolic diseases'},
    {id:'F01-F99', name:'F01-F99: Mental, Behavioral and Neurodevelopmental disorders',label:'F01-F99: Mental, Behavioral and Neurodevelopmental disorders'},
    {id:'G00-G99', name:'G00-G99: Diseases of the nervous system',label:'G00-G99: Diseases of the nervous system'},
    {id:'H00-H59', name:'H00-H59: Diseases of the eye and adnexa',label:'H00-H59: Diseases of the eye and adnexa'},

    {id:'H60-H95', name:'H60-H95: Diseases of the ear and mastoid process',label:'H60-H95: Diseases of the ear and mastoid process'},
    {id:'I00-I99', name:'I00-I99: Diseases of the circulatory system',label:'I00-I99: Diseases of the circulatory system'},
    {id:'J00-J99', name:'J00-J99: Diseases of the respiratory system',label:'J00-J99: Diseases of the respiratory system'},
    {id:'K00-K95', name:'K00-K95: Diseases of the digestive system',label:'K00-K95: Diseases of the digestive system'},
    {id:'L00-L99', name:'L00-L99: Diseases of the skin and subcutaneous tissue',label:'L00-L99: Diseases of the skin and subcutaneous tissue'},
    
    
    {id:'M00-M99', name:'M00-M99: Diseases of the musculoskeletal system and connective tissue',label:'M00-M99: Diseases of the musculoskeletal system and connective tissue'},
    {id:'N00-N99', name:'N00-N99: Diseases of the genitourinary system',label:'N00-N99: Diseases of the genitourinary system'},
    {id:'O00-O9A', name:'O00-O9A: Pregnancy, childbirth and the puerperium',label:'O00-O9A: Pregnancy, childbirth and the puerperium'},
    {id:'P00-P96', name:'P00-P96: Certain conditions originating in the perinatal period',label:'P00-P96: Certain conditions originating in the perinatal period'},
    {id:'Q00-Q99', name:'Q00-Q99: Congenital malformations, deformations and chromosomal abnormalities',label:'Q00-Q99: Congenital malformations, deformations and chromosomal abnormalities'},
    
    {id:'R00-R99', name:'R00-R99: Symptoms, signs and abnormal clinical and laboratory findings, not elsewhere classified',label:'R00-R99: Symptoms, signs and abnormal clinical and laboratory findings, not elsewhere classified'},
    {id:'S00-T88', name:'S00-T88: Injury, poisoning and certain other consequences of external causes',label:'S00-T88: Injury, poisoning and certain other consequences of external causes'},
    {id:'U00-U85', name:'U00-U85: Codes for special purposes (U07-U85)',label:'U00-U85: Codes for special purposes (U07-U85)'},

    {id:'V00-Y99', name:'V00-Y99: External causes of morbidity',label:'V00-Y99: External causes of morbidity'},
    {id:'Z00-Z99', name:'Z00-Z99: Factors influencing health status and contact with health services',label:'Z00-Z99: Factors influencing health status and contact with health services'}
]
  
export { icd10 }
  
  
  
  
  
  
  
  
  
  
  
  