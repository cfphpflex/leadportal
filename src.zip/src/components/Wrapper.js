import React, {useState,useEffect} from "react";
import { Switch, Route } from "react-router-dom";

// import AdminDashboard from "./Admin/adminDashboard";

import AddTeamMember from "./team/addTeamMember";
import EditTeamMember from "./team/editTeamMember";
import TeamManagement from "./team/teamManagement";

import Practices from "./practices/practices";
import CreateNewPractice from "./practices/createNewPractice";
import EditPractice from "./practices/editPractice";

import Patients from "./patients/patients";
import PatientInformation from "./patients/patientInformation";
import PatientProfile from "./patients/patientProfile";
import TreatmentPlan from './patients/treatmentPlan'

import Settings from './settings/settings'
import VideoCall from './videocall/videoCall'

import TreatmentPlanTemplates from "./treatment/treatmentPlanTemplates";

import Login from './Auth/login/login'
import ForgotPassword from './Auth/login/forgotPassword'
import Search from './search/search'
import Footer from "./Footer";
import Header from "./Header";
import styled from 'styled-components'
import * as api from '../provider/api'
import Backend from 'react-dnd-html5-backend'
import { DndProvider } from 'react-dnd'

import * as actions from '../provider/actions'

import {RomProvider, useRom} from '../provider/rom'

const Wrapper = () => {

  return (<DndProvider backend={Backend}>
    <RomProvider actions={actions}>
      <Header/>
      <MainWrap>
    
        <Switch>
          <Login exact path="/" />
          <ForgotPassword exact path="/password" />

          {/* <AdminDashboard exact path="/admin" /> */}
          <Search exact path="/search" />

          {/* practices */}
          <CreateNewPractice exact path="/createNewPractice" />
          <EditPractice exact path="/editPractice" />
          <Practices exact path="/practices" />

          {/* team */}
          <AddTeamMember exact path="/addTeamMember" />
          <EditTeamMember exact path="/editTeamMember" />
          <TeamManagement exact path="/teamManagement" />

          {/* patients */}
          <Patients exact path="/patients" />
          <Settings path="/(notifications|permissions)" />

          <TreatmentPlanTemplates exact path="/treatmentPlanTemplates"/>
          <PatientInformation exact path="/patientInformation/:patientID" />
          <PatientProfile exact path="/patientProfile/:patientID" />
          <TreatmentPlan exact path="/treatmentPlan/:patientID" />

          <VideoCall exact path="/romTime/:patientID" />

        </Switch>

        {/* this component only calls api and fills ui */}
        <AccountLoggedInCheck/>
        <Footer />
      </MainWrap>
    </RomProvider>
  </DndProvider>);
}

export default Wrapper

const AccountLoggedInCheck = () => {
  const rom = useRom()
  const { ui, setUI } = rom

  useEffect(()=>{
    if(!ui.token) return
    setTimeout(()=>{
      // wait for ui to fill with token
      getData()
    },500)
  },[(ui&&ui.token)])

  async function getData(){
    console.log('start getting data')
    let permissions = []
    let templates = []
    let patients = []
    let notifications = []
    let roles = []
    let practiceTypes = []

    const p = await api.post('permission/query')
    if (p&&p.results) permissions = p.results

    const t = await api.post('template/query')
    if (t&&t.results) templates = t.results

    const a = await api.post('patient/query')
    if (a&&a.results) patients = a.results

    const n = await api.post('notification/query')
    if (n&&n.results) notifications = n.results

    practiceTypes = await getTypes()
    roles = await getUserRoles()

    console.log('done getting data')
    setUI({roles,notifications,patients,permissions,practiceTypes})
    
  }

  async function getTypes(){
    const ty = await api.post('practice_type/query',null)
    if (ty) {
        let typs = []
        ty.results&&ty.results.forEach(r=>{
            typs.push({label:r.name,name:r.name,id:r.id})
        })
        return typs
    }
}

async function getUserRoles(){
  const data = { "columns" : [ "user_role_type_id" ], "search": "4"}
    const roles = []
    const r = await api.post('user_role/query',data)
    if (r) {
        r.results&&r.results.forEach(r=>{
            roles.push({label:r.name,name:r.name,id:r.id})
        })
        return roles
    }
  }
  return null
}

const MainWrap = styled.div`
  display: flex;
  flex:1;
  overflow:auto;
  height: calc(100% - 79px);
  flex-direction:column;
  align-content: center;
  align-items: center;
  ${'' /* background-color:#f6fbfc; */}
  background-color: rgba(207, 234, 239, 0.2);
`
