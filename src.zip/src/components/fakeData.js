import moment from 'moment'

export const persons = [
    {
        name:'Tony Smith',
        clinic:'Hill Crest Memorial Hospital',
        phone:'2073563569',
    },
    {
        name:'Tony Smith',
        clinic:'Hill Crest Memorial Hospital',
        phone:'2073563569',
    },
    {
        name:'Tony Smith',
        clinic:'Hill Crest Memorial Hospital',
        phone:'2073563569',
    },
]



export const fakeTreatmentTemplates = [
    {
        name:'Straightening Template',
        days:'16',
        description:'My cool template',
        isDefault:true
    },
    {
        name:'Another Cool Template',
        days:'6',
        description:'My cool template',
    },
    {
        name:'Test Template 5',
        days:'1',
        description:'Heres a test template',
    },
    {
        name:'Straightening Template 2',
        days:'16',
        description:'My cool template',
    },
]

export const fakeTeamMembers = [
    {
        name:'Michelle Smith',
        email:'hi@mail.com',
        phone:'2073563569',
        role:'Surgeon'
    },
    {
        name:'George Smith',
        email:'ha@hiya.com',
        phone:'3458765678',
        role:'Staff'
    },
    {
        name:'George Smith',
        email:'ha@hiya.com',
        phone:'3458765678',
        role:'Staff'
    },
    {
        name:'George Smith',
        email:'ha@hiya.com',
        phone:'3458765678',
        role:'Staff'
    },
    {
        name:'George Smith',
        email:'ha@hiya.com',
        phone:'3458765678',
        role:'Staff'
    },
]

export const devices = [
    {
        device:'PortableConnect',
        serialNumber:'5734573547',
        status:'In Stock',
    },
    {
        device:'PortableConnect',
        serialNumber:'2346473745',
        status:'In Stock',
    },
    {
        device:'PortableConnect',
        serialNumber:'2346473745',
        status:'In Stock',
    },
    {
        device:'AccuAngle',
        serialNumber:'3450746',
        status:'In Stock',
    },
    {
        device:'AccuStep',
        serialNumber:'2346473745',
        status:'Cleaning',
    },
    {
        device:'PortableConnect',
        serialNumber:'2346473745',
        status:'Returned',
    },
    
]

export const patients = [
        {
            name:'L, Robert',
            pt:'John Smith',
            age:'71',
            email:'hi@hotmail.com',
            dme:'-',
            extension:'34°',
            surgeon:'Michelle Jones',
            procedure:'Knee Replacement (L)',
            procedureDate:moment().format('llll'),
            postOpDay:3,
            pain:6,
            romExtF:'23/40',
            flexion:102,
            sessionCompTot:'18/83',
            lastSession:moment().format('llll'),
            alerts:[],
            id:34,
            pcSerial:'f3748q474fga478',
            aaSerial:'afw87gawfggoia',
            asSerial:'aw7afw9b87af',
            location:'Olympia, WA',
            daysRemaining:10
        },
        {
            name:'P, Michelle',
            pt:'John Smith',
            age:'71',
            email:'hi@hotmail.com',
            dme:'-',
            extension:'34°',
            surgeon:'Michelle Jones',
            procedure:'Knee Replacement (L)',
            procedureDate:moment().format('llll'),
            postOpDay:3,
            pain:6,
            romExtF:'23/40',
            flexion:102,
            sessionCompTot:'18/83',
            lastSession:moment().format('llll'),
            alerts:[],
            id:34,
            pcSerial:'f3748q474fga478',
            aaSerial:'afw87gawfggoia',
            asSerial:'aw7afw9b87af',
            location:'Seattle, WA',
            daysRemaining:10
        },
        {
        name:'L, Robert',
        pt:'John Smith',
        age:'71',
        email:'hi@hotmail.com',
        dme:'-',
        surgeon:'Michelle Jones',
        procedure:'Knee Replacement (L)',
        procedureDate:moment().format('llll'),
        postOpDay:3,
        pain:6,
        extension:'34°',
        romExtF:'23/40',
        flexion:102,
        sessionCompTot:'18/83',
        lastSession:moment().format('llll'),
        alerts:[],
        id:34,
        pcSerial:'f3748q474fga478',
        aaSerial:'afw87gawfggoia',
        asSerial:'aw7afw9b87af',
        location:'Olympia, WA',
        daysRemaining:10,
        treatmentStartDate:moment().format('llll'),
    },
    {
        dme:'-',
        name:'P, Michelle',
        pt:'John Smith',
        age:'71',
        email:'hi@hotmail.com',
        surgeon:'Charlie Jones', 
        procedure:'Knee Replacement (R)',
        procedureDate:moment().format('llll'),
        postOpDay:3,
        extension:'34°',
        pain:6,
        romExtF:'23/40',
        flexion:102,
        sessionCompTot:'18/83',
        lastSession:moment().format('llll'),
        alerts:['UH OH','FIXED'],
        id:210,
        pcSerial:'f3748q474fga478',
        aaSerial:'afw87gawfggoia',
        asSerial:'aw7afw9b87af',
        location:'Portland, WA',
        daysRemaining:31,
        treatmentStartDate:moment().format('llll'),
    },
    ]

    export const fakePractices = [
        {
            name:'Hope Haven Medical Center',
            type:'Solo',
            location:'Austin, TX',
            phone:'2073563569',
        },
        {
            name:'White Mountain Clinic',
            type:'Group',
            location:'Seattle, WA',
            phone:'2073563569',
        },
        {
            name:'Hope Haven Medical Center',
            type:'Solo',
            location:'Austin, TX',
            phone:'2073563569',
        },
        {
            name:'White Mountain Clinic',
            type:'Group',
            location:'Seattle, WA',
            phone:'2073563569',
        },
        {
            name:'Hope Haven Medical Center',
            type:'Solo',
            location:'Austin, TX',
            phone:'2073563569',
        },
        {
            name:'White Mountain Clinic',
            type:'Group',
            location:'Seattle, WA',
            phone:'2073563569',
        }
    ]

export const chartStyles={
    fill: false,
    lineTension: 0.1,
    backgroundColor: "#0899b7",
    borderColor: "#0899b7",
    borderCapStyle: "butt",
    pointBackgroundColor: "#0899b7",
    pointBorderWidth: 2,
    pointHoverBackgroundColor: "rgba(75,192,192,1)",
    pointHoverBorderColor: "rgba(220,220,220,1)",
    pointHoverBorderWidth: 1,
    pointRadius: 5,
    pointHoverRadius: 10,
    pointHitRadius: 10,
}
export const chartData = {
    // labels: [1, "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"],
    datasets: [
      {
        data: [50, 41, 42, 39, 40, 42, 56, 52, 45, 49, 52, 59, 65, 66, 70, 80, 70, 71, 72, 69, 70, 72, 86, 82, 75, 79, 82, 89, 95, 96, 100, 100],
        ...chartStyles,
      },
    ],
};

export const sessions=[
    {value:14,time:moment().format('hh:mm a')},
    {value:15,time:moment().format('hh:mm a')},
    {value:16,time:moment().format('hh:mm a')},
    {value:18,time:moment().format('hh:mm a')},
    {value:22,time:moment().format('hh:mm a')},
]

export const adminStatData = [
    {
        label:'Treatment Plans in Progress',
        value:13
    },
    {
        label:'Treatment Plans Completed in 21 Days',
        value:15
    },
    {
        label:'Total Sessions Completed From All Patients',
        value:256
    },
    {
        label:'Completed Treatment Plans',
        value:1
    }
]

export const adminChartData = {
    labels: ["SUN", "MON", "TUES", "WED", "THU", "FRI", "SAT"],
    datasets: [
      {
        data: [40, 41, 42, 49, 50, 52, 56],
        ...chartStyles,
      },
    ],
};
