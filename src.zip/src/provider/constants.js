let URL = 'http://portal_api.romtechdev.com/api/'

export {
    URL,
}